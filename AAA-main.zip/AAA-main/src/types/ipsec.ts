export type VPNMode = 'Tunnel' | 'Transport';
export type IPVersion = 'IPv4' | 'IPv6';
export type IKEVersion = 'IKEv1' | 'IKEv2';
export type IKEMode = 'Main Mode' | 'Aggressive Mode' | 'IKE_SA_INIT' | 'IKE_AUTH';

export type EncryptionAlgo = 
  | 'AES-256-GCM' 
  | 'AES-128-GCM' 
  | 'AES-256-CBC' 
  | 'AES-128-CBC' 
  | '3DES-CBC' 
  | 'ChaCha20-Poly1305' 
  | 'DES-CBC' 
  | 'NULL';

export type AuthAlgo = 
  | 'HMAC-SHA512' 
  | 'HMAC-SHA384' 
  | 'HMAC-SHA256' 
  | 'HMAC-SHA1' 
  | 'HMAC-MD5' 
  | 'AES-GMAC' 
  | 'Poly1305';

export interface DHGroup {
  id: number;
  name: string;
  bitLength: number;
  type: 'MODP' | 'ECP' | 'Curve25519';
  securityRating: 'INSECURE' | 'LEGACY' | 'ACCEPTABLE' | 'RECOMMENDED' | 'MILITARY_GRADE';
}

export type TrafficType = 
  | 'VoIP (RTP)' 
  | 'WhatsApp / Messaging' 
  | 'Video Streaming (HLS/DASH)' 
  | 'Web Browsing (HTTPS)' 
  | 'Email (SMTP/IMAP)' 
  | 'ICMP / Network Diagnostics' 
  | 'File Transfer (SFTP/SCP)';

export interface PacketDissection {
  id: number;
  timestamp: string;
  relativeTime: number; // in seconds
  sourceIp: string;
  destIp: string;
  ipVersion: IPVersion;
  protocol: 'ESP (50)' | 'AH (51)' | 'IKEv2 (UDP 500)' | 'IKEv2-NAT-T (UDP 4500)' | 'IKEv1 (UDP 500)';
  length: number;
  info: string;
  spi?: string;
  seqNum?: number;
  ikeExchangeType?: string;
  ikeMessageId?: number;
  flags?: string[];
  payloadSummary?: string;
  rawHex: string;
  innerPayloadInference?: {
    trafficType: TrafficType;
    confidence: number;
    entropy: number;
  };
  dissectedLayers: {
    layerName: string;
    fields: { name: string; value: string | number; hexOffset?: string; description?: string }[];
  }[];
}

export interface SecurityAssociation {
  spiIn: string;
  spiOut: string;
  mode: VPNMode;
  encryptionAlgo: EncryptionAlgo;
  authAlgo: AuthAlgo;
  dhGroup: DHGroup;
  pfsEnabled: boolean;
  keyLifetimeSeconds: number;
  keyLifetimeKilobytes: number;
  replayWindowSize: number;
  replayProtectionEnabled: boolean;
  initiatorIp: string;
  responderIp: string;
  natTraversal: boolean;
}

export interface XGBoostFlowFeatures {
  meanPacketSize: number;
  stdPacketSize: number;
  maxPacketSize: number;
  minPacketSize: number;
  meanInterArrivalTimeMs: number;
  stdInterArrivalTimeMs: number;
  burstRatio: number;
  payloadEntropy: number;
  directionalRatio: number; // in vs out
  totalPackets: number;
  totalBytes: number;
  flowDurationMs: number;
}

export interface XGBoostPredictionResult {
  predictedClass: TrafficType;
  confidence: number; // 0.0 - 1.0
  classProbabilities: { [key in TrafficType]?: number };
  featureImportance: { feature: string; shapValue: number; importancePct: number; value: number | string }[];
  aiExplanation: string;
}

export interface SecurityFinding {
  id: string;
  title: string;
  severity: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW' | 'INFO';
  category: 'Cryptographic Weakness' | 'Protocol Vulnerability' | 'Configuration Flaw' | 'Compliance Violation' | 'Metadata Exposure';
  cveOrRfc?: string;
  description: string;
  impact: string;
  recommendation: string;
  remediationSnippet?: string;
}

export interface ComplianceCheck {
  standard: 'NIST SP 800-77 Rev 1' | 'RFC 8221 (IPsec Crypto)' | 'RFC 7321 (IKEv2 Crypto)' | 'ANSSI Strict' | 'BSI TR-02102-3';
  status: 'COMPLIANT' | 'NON_COMPLIANT' | 'WARNING';
  passedRules: number;
  totalRules: number;
  details: string[];
}

export interface SecurityAssessmentReport {
  overallScore: number; // 0 - 100
  riskLevel: 'CRITICAL RISK' | 'HIGH RISK' | 'MODERATE RISK' | 'LOW RISK' | 'HARDENED / SECURE';
  aiConfidenceScore: number; // 0 - 100
  assessmentTimestamp: string;
  summaryNarrative: string;
  identifiedProtocol: {
    protocolName: string;
    ikeVersion: IKEVersion;
    inferredMode: VPNMode;
    encryption: EncryptionAlgo;
    authentication: AuthAlgo;
    dhGroup: DHGroup;
    pfs: boolean;
    ipVersion: IPVersion;
  };
  findings: SecurityFinding[];
  complianceChecks: ComplianceCheck[];
  threatMatrix: {
    threat: string;
    likelihood: 'HIGH' | 'MEDIUM' | 'LOW';
    impact: 'HIGH' | 'MEDIUM' | 'LOW';
    status: 'VULNERABLE' | 'MITIGATED' | 'PROTECTED';
    description: string;
  }[];
  predictedTraffic: {
    trafficType: TrafficType;
    confidence: number;
    topFeatures: string[];
  };
  remediationRoadmap: {
    stepNumber: number;
    title: string;
    action: string;
    priority: 'IMMEDIATE' | 'HIGH' | 'MEDIUM';
    configDiff?: string;
  }[];
}

export interface TestbedConfig {
  id: string;
  name: string;
  description: string;
  vpnMode: VPNMode;
  ikeVersion: IKEVersion;
  ikeMode: IKEMode;
  encryptionAlgo: EncryptionAlgo;
  authAlgo: AuthAlgo;
  dhGroupId: number;
  pfsEnabled: boolean;
  ipVersion: IPVersion;
  trafficType: TrafficType;
  keyLifetimeHours: number;
  replayProtection: boolean;
  packetCount: number;
}
