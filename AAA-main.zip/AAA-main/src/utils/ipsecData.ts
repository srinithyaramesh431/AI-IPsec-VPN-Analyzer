import { DHGroup, TestbedConfig, PacketDissection, SecurityAssessmentReport, ComplianceCheck } from '../types/ipsec';

export const DH_GROUPS: Record<number, DHGroup> = {
  1: { id: 1, name: 'Group 1 (768-bit MODP)', bitLength: 768, type: 'MODP', securityRating: 'INSECURE' },
  2: { id: 2, name: 'Group 2 (1024-bit MODP)', bitLength: 1024, type: 'MODP', securityRating: 'INSECURE' },
  5: { id: 5, name: 'Group 5 (1536-bit MODP)', bitLength: 1536, type: 'MODP', securityRating: 'LEGACY' },
  14: { id: 14, name: 'Group 14 (2048-bit MODP)', bitLength: 2048, type: 'MODP', securityRating: 'ACCEPTABLE' },
  19: { id: 19, name: 'Group 19 (256-bit ECP)', bitLength: 256, type: 'ECP', securityRating: 'RECOMMENDED' },
  20: { id: 20, name: 'Group 20 (384-bit ECP)', bitLength: 384, type: 'ECP', securityRating: 'RECOMMENDED' },
  21: { id: 21, name: 'Group 21 (521-bit ECP)', bitLength: 521, type: 'ECP', securityRating: 'MILITARY_GRADE' },
  31: { id: 31, name: 'Group 31 (Curve25519)', bitLength: 256, type: 'Curve25519', securityRating: 'RECOMMENDED' }
};

export const PRESET_SCENARIOS: TestbedConfig[] = [
  {
    id: 'modern-enterprise-ikev2',
    name: 'Scenario 1: Modern Enterprise (IKEv2, AES-256-GCM, DH-19, PFS)',
    description: 'Hardened cloud site-to-site VPN using modern IKEv2 with authenticated encryption (AES-256-GCM), Elliptic Curve DH Group 19, and Perfect Forward Secrecy.',
    vpnMode: 'Tunnel',
    ikeVersion: 'IKEv2',
    ikeMode: 'IKE_SA_INIT',
    encryptionAlgo: 'AES-256-GCM',
    authAlgo: 'AES-GMAC',
    dhGroupId: 19,
    pfsEnabled: true,
    ipVersion: 'IPv4',
    trafficType: 'Video Streaming (HLS/DASH)',
    keyLifetimeHours: 8,
    replayProtection: true,
    packetCount: 50
  },
  {
    id: 'legacy-ikev1-weak',
    name: 'Scenario 2: Critical Legacy IKEv1 (3DES + MD5, DH-2)',
    description: 'Vulnerable enterprise deployment using deprecated IKEv1 Aggressive mode, 3DES cipher vulnerable to Sweet32, MD5 collision risk, and 1024-bit DH Group 2 (Logjam vulnerable).',
    vpnMode: 'Tunnel',
    ikeVersion: 'IKEv1',
    ikeMode: 'Aggressive Mode',
    encryptionAlgo: '3DES-CBC',
    authAlgo: 'HMAC-MD5',
    dhGroupId: 2,
    pfsEnabled: false,
    ipVersion: 'IPv4',
    trafficType: 'WhatsApp / Messaging',
    keyLifetimeHours: 72,
    replayProtection: false,
    packetCount: 48
  },
  {
    id: 'branch-office-medium-risk',
    name: 'Scenario 3: Branch VPN (IKEv1 Main Mode, AES-CBC + SHA1, DH-5)',
    description: 'Aging branch office tunnel with SHA-1 integrity, 1536-bit DH group, and disabled Perfect Forward Secrecy leaving session keys vulnerable to retrospective decryption.',
    vpnMode: 'Tunnel',
    ikeVersion: 'IKEv1',
    ikeMode: 'Main Mode',
    encryptionAlgo: 'AES-128-CBC',
    authAlgo: 'HMAC-SHA1',
    dhGroupId: 5,
    pfsEnabled: false,
    ipVersion: 'IPv4',
    trafficType: 'VoIP (RTP)',
    keyLifetimeHours: 24,
    replayProtection: true,
    packetCount: 52
  },
  {
    id: 'modern-enterprise-ikev2',
    name: 'Scenario 3: Modern Enterprise (IKEv2, AES-256-GCM, DH-19 ECP)',
    description: 'Compliant cloud site-to-site VPN using modern IKEv2 with authenticated encryption (AES-256-GCM), Elliptic Curve DH Group 19, and Perfect Forward Secrecy.',
    vpnMode: 'Tunnel',
    ikeVersion: 'IKEv2',
    ikeMode: 'IKE_SA_INIT',
    encryptionAlgo: 'AES-256-GCM',
    authAlgo: 'AES-GMAC',
    dhGroupId: 19,
    pfsEnabled: true,
    ipVersion: 'IPv4',
    trafficType: 'Video Streaming (HLS/DASH)',
    keyLifetimeHours: 8,
    replayProtection: true,
    packetCount: 64
  },
  {
    id: 'defense-grade-ipv6',
    name: 'Scenario 4: Defense-Grade IPv6 (IKEv2, ChaCha20, DH-21 ECP-521)',
    description: 'Ultra-secure government & defense deployment operating over IPv6 with 521-bit elliptic curves, PFS enabled, replay protection, and authenticated file transfer.',
    vpnMode: 'Tunnel',
    ikeVersion: 'IKEv2',
    ikeMode: 'IKE_SA_INIT',
    encryptionAlgo: 'ChaCha20-Poly1305',
    authAlgo: 'Poly1305',
    dhGroupId: 21,
    pfsEnabled: true,
    ipVersion: 'IPv6',
    trafficType: 'File Transfer (SFTP/SCP)',
    keyLifetimeHours: 4,
    replayProtection: true,
    packetCount: 70
  },
  {
    id: 'host-to-host-transport',
    name: 'Scenario 5: Host Transport Mode (AES-128-GCM, DH-14)',
    description: 'Transport Mode IPsec securing server-to-server intra-datacenter communications without extra IP tunneling headers. Fast throughput with low encapsulation overhead.',
    vpnMode: 'Transport',
    ikeVersion: 'IKEv2',
    ikeMode: 'IKE_SA_INIT',
    encryptionAlgo: 'AES-128-GCM',
    authAlgo: 'AES-GMAC',
    dhGroupId: 14,
    pfsEnabled: true,
    ipVersion: 'IPv4',
    trafficType: 'ICMP / Network Diagnostics',
    keyLifetimeHours: 12,
    replayProtection: true,
    packetCount: 40
  }
];

export const SAMPLE_PRESET_SCENARIOS = PRESET_SCENARIOS;
export const DEFAULT_TESTBED_CONFIG: TestbedConfig = PRESET_SCENARIOS[2];

export function generateSyntheticTrace(config: TestbedConfig): PacketDissection[] {
  const dh = DH_GROUPS[config.dhGroupId] || DH_GROUPS[14];
  const packets: PacketDissection[] = [];
  let currentTime = 0.000;

  const isV6 = config.ipVersion === 'IPv6';
  const initiatorIp = isV6 ? '2001:db8:85a3::8a2e:370:7334' : '198.51.100.10';
  const responderIp = isV6 ? '2001:db8:85a3::8a2e:370:8888' : '203.0.113.50';

  const spiInitiator = '0x9a8f4c21e0b5137d';
  const spiResponder = '0x17b3d928f6c40e51';
  const espSpiIn = '0x0d4f912c';
  const espSpiOut = '0x8e2b704a';

  let packetId = 1;

  if (config.ikeVersion === 'IKEv1') {
    if (config.ikeMode === 'Aggressive Mode') {
      // Aggressive Mode packet 1
      packets.push({
        id: packetId++,
        timestamp: '09:14:02.104230',
        relativeTime: currentTime,
        sourceIp: initiatorIp,
        destIp: responderIp,
        ipVersion: config.ipVersion,
        protocol: 'IKEv1 (UDP 500)',
        length: 298,
        info: `IKEv1 Aggressive Mode Request [SA, KE (${dh.name}), Nonce, ID (fqdn=vpn.corp.local)]`,
        ikeExchangeType: 'Aggressive Mode (4)',
        ikeMessageId: 0,
        flags: ['Initiator'],
        payloadSummary: `SA Prop: ${config.encryptionAlgo}, ${config.authAlgo}, DH ${dh.id} | KE payload (${dh.bitLength} bits) | ID (cleartext exposure!)`,
        rawHex: '00 00 00 00 9a 8f 4c 21 e0 b5 13 7d 00 00 00 00 01 10 04 00 00 00 00 00 00 00 01 2a ... [SA Transform + DH PubKey + ID]',
        dissectedLayers: [
          {
            layerName: 'Internet Protocol (IP)',
            fields: [
              { name: 'Version', value: config.ipVersion },
              { name: 'Source', value: initiatorIp },
              { name: 'Destination', value: responderIp },
              { name: 'Protocol', value: 'UDP (17)' }
            ]
          },
          {
            layerName: 'User Datagram Protocol (UDP)',
            fields: [
              { name: 'Source Port', value: 500 },
              { name: 'Destination Port', value: 500 },
              { name: 'Length', value: 278 }
            ]
          },
          {
            layerName: 'Internet Security Association and Key Management Protocol (ISAKMP)',
            fields: [
              { name: 'Initiator Cookie', value: spiInitiator },
              { name: 'Responder Cookie', value: '0x0000000000000000' },
              { name: 'Exchange Type', value: 'Aggressive (4)' },
              { name: 'Flags', value: 'None' },
              { name: 'Message ID', value: '0x00000000' },
              { name: 'Next Payload', value: 'Security Association (1)' },
              { name: 'Transform Proposal', value: `${config.encryptionAlgo} | ${config.authAlgo} | DH ${dh.id} (${dh.name})` },
              { name: 'Identity Payload (ID)', value: 'vpn.corp.local (Transmitted in plaintext!)', description: 'Vulnerable to offline pre-shared key dictionary attack' }
            ]
          }
        ]
      });

      currentTime += 0.042;
      // Aggressive Mode packet 2
      packets.push({
        id: packetId++,
        timestamp: '09:14:02.146231',
        relativeTime: currentTime,
        sourceIp: responderIp,
        destIp: initiatorIp,
        ipVersion: config.ipVersion,
        protocol: 'IKEv1 (UDP 500)',
        length: 312,
        info: `IKEv1 Aggressive Mode Response [SA Selected, KE Response, Nonce, ID, HASH_R]`,
        ikeExchangeType: 'Aggressive Mode (4)',
        ikeMessageId: 0,
        flags: ['Response'],
        payloadSummary: `Selected SA: ${config.encryptionAlgo}, ${config.authAlgo} | Responder DH PubKey | HASH_R authentication hash`,
        rawHex: '9a 8f 4c 21 e0 b5 13 7d 17 b3 d9 28 f6 c4 0e 51 01 10 04 00 00 00 00 00 00 00 01 38 ...',
        dissectedLayers: [
          {
            layerName: 'ISAKMP Response',
            fields: [
              { name: 'Initiator Cookie', value: spiInitiator },
              { name: 'Responder Cookie', value: spiResponder },
              { name: 'Exchange Type', value: 'Aggressive (4)' },
              { name: 'Selected Transform', value: `${config.encryptionAlgo}, ${config.authAlgo}, ${dh.name}` },
              { name: 'HASH_R Verification', value: '0x4f82a9c1e2b8...' }
            ]
          }
        ]
      });

      currentTime += 0.018;
      // Aggressive Mode packet 3 (HASH_I)
      packets.push({
        id: packetId++,
        timestamp: '09:14:02.164231',
        relativeTime: currentTime,
        sourceIp: initiatorIp,
        destIp: responderIp,
        ipVersion: config.ipVersion,
        protocol: 'IKEv1 (UDP 500)',
        length: 92,
        info: `IKEv1 Aggressive Mode Completion [HASH_I (Initiator Authentication)]`,
        ikeExchangeType: 'Aggressive Mode (4)',
        ikeMessageId: 0,
        flags: ['Initiator'],
        payloadSummary: 'Phase 1 ISAKMP SA established.',
        rawHex: '9a 8f 4c 21 e0 b5 13 7d 17 b3 d9 28 f6 c4 0e 51 08 10 04 00 00 00 00 00 00 00 00 5c ...',
        dissectedLayers: [
          {
            layerName: 'ISAKMP Completion',
            fields: [
              { name: 'Phase 1 Status', value: 'ESTABLISHED' },
              { name: 'HASH_I', value: '0x7e11c9d4b532a8f0' }
            ]
          }
        ]
      });
    } else {
      // Main Mode 6 packets
      const mainModeSteps = [
        { name: 'Main Mode Msg 1 (SA Offer)', desc: 'Initiator sends SA proposals' },
        { name: 'Main Mode Msg 2 (SA Select)', desc: 'Responder chooses matching SA' },
        { name: 'Main Mode Msg 3 (KE & Nonce Initiator)', desc: `Initiator sends DH ${dh.name} Public Key` },
        { name: 'Main Mode Msg 4 (KE & Nonce Responder)', desc: `Responder sends DH ${dh.name} Public Key` },
        { name: 'Main Mode Msg 5 (Encrypted Auth ID)', desc: 'Initiator encrypted ID and Hash' },
        { name: 'Main Mode Msg 6 (Encrypted Auth ID)', desc: 'Responder encrypted ID and Hash' }
      ];

      for (let i = 0; i < 6; i++) {
        currentTime += 0.025;
        const isInit = i % 2 === 0;
        packets.push({
          id: packetId++,
          timestamp: `09:14:02.${(100 + i * 28).toString().padStart(6, '0')}`,
          relativeTime: currentTime,
          sourceIp: isInit ? initiatorIp : responderIp,
          destIp: isInit ? responderIp : initiatorIp,
          ipVersion: config.ipVersion,
          protocol: 'IKEv1 (UDP 500)',
          length: i < 4 ? 240 + i * 16 : 108,
          info: `IKEv1 Main Mode: ${mainModeSteps[i].name}`,
          ikeExchangeType: 'Main Mode (2)',
          ikeMessageId: 0,
          flags: [isInit ? 'Initiator' : 'Response', i >= 4 ? 'Encrypted' : 'Unencrypted'],
          payloadSummary: `${mainModeSteps[i].desc} | Cipher: ${config.encryptionAlgo}, DH: ${dh.name}`,
          rawHex: '9a 8f 4c 21 e0 b5 13 7d ' + (i === 0 ? '00 00 00 00 00 00 00 00' : '17 b3 d9 28 f6 c4 0e 51') + ' 01 10 02 00 ...',
          dissectedLayers: [
            {
              layerName: 'ISAKMP Main Mode',
              fields: [
                { name: 'Step', value: `${i + 1} of 6` },
                { name: 'Summary', value: mainModeSteps[i].name },
                { name: 'Encryption State', value: i >= 4 ? 'Encrypted via SKEYID_e' : 'Plaintext' },
                { name: 'DH Group', value: `${dh.name} (${dh.bitLength} bits)` }
              ]
            }
          ]
        });
      }
    }
  } else {
    // IKEv2 Handshake: IKE_SA_INIT (2 pkts) + IKE_AUTH (2 pkts)
    currentTime += 0.015;
    packets.push({
      id: packetId++,
      timestamp: '09:14:02.115420',
      relativeTime: currentTime,
      sourceIp: initiatorIp,
      destIp: responderIp,
      ipVersion: config.ipVersion,
      protocol: 'IKEv2 (UDP 500)',
      length: 340,
      info: `IKE_SA_INIT Request [SA, KE (${dh.name}), Nonce_I, Notify: NAT_DETECTION]`,
      ikeExchangeType: 'IKE_SA_INIT (34)',
      ikeMessageId: 0,
      flags: ['Initiator', 'IKEv2'],
      payloadSummary: `Proposal: ENCR=${config.encryptionAlgo}, PRF=${config.authAlgo}, DH=${dh.name} | Key Exchange data (${dh.bitLength} bits)`,
      rawHex: '9a 8f 4c 21 e0 b5 13 7d 00 00 00 00 00 00 00 00 21 20 22 08 00 00 00 00 00 00 01 54 ... [SA + KE + Ni + NAT_D]',
      dissectedLayers: [
        {
          layerName: 'IKEv2 Header',
          fields: [
            { name: 'Initiator SPI', value: spiInitiator },
            { name: 'Responder SPI', value: '0x0000000000000000' },
            { name: 'Exchange Type', value: 'IKE_SA_INIT (34)' },
            { name: 'Major Version', value: '2' },
            { name: 'Minor Version', value: '0' },
            { name: 'Message ID', value: '0' }
          ]
        },
        {
          layerName: 'Payload: Security Association (SA)',
          fields: [
            { name: 'Proposal #1 Transform ENCR', value: config.encryptionAlgo },
            { name: 'Proposal #1 Transform PRF', value: config.authAlgo },
            { name: 'Proposal #1 Transform DH', value: dh.name },
            { name: 'PFS Requirement', value: config.pfsEnabled ? 'Enabled (Child SA will DH exchange)' : 'Disabled' }
          ]
        },
        {
          layerName: 'Payload: Key Exchange (KE)',
          fields: [
            { name: 'DH Group #', value: dh.id },
            { name: 'Group Name', value: dh.name },
            { name: 'Key Length', value: `${dh.bitLength} bits (${dh.type})` },
            { name: 'Key Exchange Data', value: '0x93e712a4bb01c5f89e23...' }
          ]
        }
      ]
    });

    currentTime += 0.035;
    packets.push({
      id: packetId++,
      timestamp: '09:14:02.150420',
      relativeTime: currentTime,
      sourceIp: responderIp,
      destIp: initiatorIp,
      ipVersion: config.ipVersion,
      protocol: 'IKEv2 (UDP 500)',
      length: 356,
      info: `IKE_SA_INIT Response [SA Selected, KE (${dh.name}), Nonce_R, CertReq]`,
      ikeExchangeType: 'IKE_SA_INIT (34)',
      ikeMessageId: 0,
      flags: ['Response', 'IKEv2'],
      payloadSummary: `Selected SA Transform: ${config.encryptionAlgo}, DH=${dh.name} | Shared secret SKEYSEED computed`,
      rawHex: '9a 8f 4c 21 e0 b5 13 7d 17 b3 d9 28 f6 c4 0e 51 21 20 22 20 00 00 00 00 00 00 01 64 ...',
      dissectedLayers: [
        {
          layerName: 'IKEv2 Header',
          fields: [
            { name: 'Initiator SPI', value: spiInitiator },
            { name: 'Responder SPI', value: spiResponder },
            { name: 'Exchange Type', value: 'IKE_SA_INIT (34)' },
            { name: 'Status', value: 'Accepted Proposal' }
          ]
        }
      ]
    });

    currentTime += 0.022;
    packets.push({
      id: packetId++,
      timestamp: '09:14:02.172420',
      relativeTime: currentTime,
      sourceIp: initiatorIp,
      destIp: responderIp,
      ipVersion: config.ipVersion,
      protocol: 'IKEv2 (UDP 500)',
      length: 276,
      info: `IKE_AUTH Request [Encrypted: IDi, AUTH, SA (Child ESP), TSi, TSr]`,
      ikeExchangeType: 'IKE_AUTH (35)',
      ikeMessageId: 1,
      flags: ['Initiator', 'Encrypted Payload'],
      payloadSummary: `Child SA Creation: Mode=${config.vpnMode}, SPI_In=${espSpiIn}, Traffic Selectors negotiated`,
      rawHex: '9a 8f 4c 21 e0 b5 13 7d 17 b3 d9 28 f6 c4 0e 51 2e 20 23 08 00 00 00 01 00 00 01 14 ... [SK payload]',
      dissectedLayers: [
        {
          layerName: 'Encrypted and Authenticated Payload (SK)',
          fields: [
            { name: 'Child SA Mode', value: config.vpnMode },
            { name: 'Cipher Suite', value: `${config.encryptionAlgo} + ${config.authAlgo}` },
            { name: 'Traffic Selector Initiator (TSi)', value: '0.0.0.0/0 (All IPv4 traffic)' },
            { name: 'Traffic Selector Responder (TSr)', value: '0.0.0.0/0 (All IPv4 traffic)' }
          ]
        }
      ]
    });

    currentTime += 0.028;
    packets.push({
      id: packetId++,
      timestamp: '09:14:02.200420',
      relativeTime: currentTime,
      sourceIp: responderIp,
      destIp: initiatorIp,
      ipVersion: config.ipVersion,
      protocol: 'IKEv2 (UDP 500)',
      length: 292,
      info: `IKE_AUTH Response [Encrypted: IDr, AUTH, SA (Child ESP Accepted), TSi, TSr]`,
      ikeExchangeType: 'IKE_AUTH (35)',
      ikeMessageId: 1,
      flags: ['Response', 'Encrypted Payload'],
      payloadSummary: `IPsec SA successfully established! Outgoing SPI=${espSpiOut}, Lifetime=${config.keyLifetimeHours}h`,
      rawHex: '9a 8f 4c 21 e0 b5 13 7d 17 b3 d9 28 f6 c4 0e 51 2e 20 23 20 00 00 00 01 00 00 01 24 ...',
      dissectedLayers: [
        {
          layerName: 'IKEv2 Child SA Established',
          fields: [
            { name: 'Inbound SPI', value: espSpiIn },
            { name: 'Outbound SPI', value: espSpiOut },
            { name: 'Operating Mode', value: config.vpnMode },
            { name: 'Replay Window', value: config.replayProtection ? '64-packet window active' : 'DISABLED (Vulnerable)' }
          ]
        }
      ]
    });
  }

  // Now generate ESP Data Packets (encapsulating the specified traffic type)
  const remainingCount = Math.max(config.packetCount - packets.length, 12);
  const trafficProfile = getTrafficProfile(config.trafficType);

  for (let i = 0; i < remainingCount; i++) {
    const isOutbound = Math.random() < trafficProfile.outboundProbability;
    const packetLength = Math.floor(
      trafficProfile.minLen + Math.random() * (trafficProfile.maxLen - trafficProfile.minLen)
    );
    const iat = trafficProfile.meanIatMs * (0.6 + Math.random() * 0.8) / 1000;
    currentTime += iat;

    const seq = i + 1;
    const currentSpi = isOutbound ? espSpiOut : espSpiIn;
    const src = isOutbound ? initiatorIp : responderIp;
    const dst = isOutbound ? responderIp : initiatorIp;

    packets.push({
      id: packetId++,
      timestamp: `09:14:${(2 + Math.floor(currentTime)).toString().padStart(2, '0')}.${Math.floor((currentTime % 1) * 1000000).toString().padStart(6, '0')}`,
      relativeTime: parseFloat(currentTime.toFixed(4)),
      sourceIp: src,
      destIp: dst,
      ipVersion: config.ipVersion,
      protocol: 'ESP (50)',
      length: packetLength + (config.vpnMode === 'Tunnel' ? 40 : 20),
      info: `ESP Packet [SPI: ${currentSpi}, Seq: ${seq}, Len: ${packetLength}B]`,
      spi: currentSpi,
      seqNum: seq,
      payloadSummary: `Encapsulated ${config.vpnMode} Mode payload (${config.trafficType}) | Cipher: ${config.encryptionAlgo}`,
      rawHex: `${currentSpi.replace('0x', '')} ${seq.toString(16).padStart(8, '0')} 4a 9c 1e d7 82 04 fb 11 c2 99 ... [Encrypted ${config.trafficType} Data + ICV/HMAC]`,
      innerPayloadInference: {
        trafficType: config.trafficType,
        confidence: trafficProfile.expectedConfidence + (Math.random() * 0.05 - 0.02),
        entropy: trafficProfile.entropy
      },
      dissectedLayers: [
        {
          layerName: config.vpnMode === 'Tunnel' ? 'Outer IP Header (Tunnel Endpoint)' : 'IP Header',
          fields: [
            { name: 'Source IP', value: src },
            { name: 'Destination IP', value: dst },
            { name: 'Protocol', value: 'ESP (50)' },
            { name: 'Total Length', value: packetLength + (config.vpnMode === 'Tunnel' ? 40 : 20) }
          ]
        },
        {
          layerName: 'Encapsulating Security Payload (ESP Header & Trailer)',
          fields: [
            { name: 'Security Parameters Index (SPI)', value: currentSpi },
            { name: 'Sequence Number', value: seq },
            { name: 'Payload Data (Encrypted)', value: `[${packetLength} bytes ciphertext]` },
            { name: 'Encryption Cipher', value: config.encryptionAlgo },
            { name: 'Integrity Check Value (ICV)', value: config.authAlgo === 'AES-GMAC' ? '16-byte GCM Tag' : 'HMAC Output' },
            { name: 'Inferred Encapsulated Mode', value: `${config.vpnMode} Mode (${config.vpnMode === 'Tunnel' ? 'Contains inner IP header' : 'Direct Transport header'})` }
          ]
        }
      ]
    });
  }

  return packets;
}

function getTrafficProfile(trafficType: string) {
  switch (trafficType) {
    case 'VoIP (RTP)':
      return { minLen: 160, maxLen: 240, meanIatMs: 20, outboundProbability: 0.5, entropy: 7.96, expectedConfidence: 0.96 };
    case 'WhatsApp / Messaging':
      return { minLen: 120, maxLen: 420, meanIatMs: 380, outboundProbability: 0.45, entropy: 7.92, expectedConfidence: 0.94 };
    case 'Video Streaming (HLS/DASH)':
      return { minLen: 1100, maxLen: 1460, meanIatMs: 8, outboundProbability: 0.12, entropy: 7.98, expectedConfidence: 0.98 };
    case 'Web Browsing (HTTPS)':
      return { minLen: 300, maxLen: 1420, meanIatMs: 85, outboundProbability: 0.35, entropy: 7.95, expectedConfidence: 0.92 };
    case 'Email (SMTP/IMAP)':
      return { minLen: 220, maxLen: 980, meanIatMs: 140, outboundProbability: 0.55, entropy: 7.94, expectedConfidence: 0.93 };
    case 'ICMP / Network Diagnostics':
      return { minLen: 84, maxLen: 96, meanIatMs: 1000, outboundProbability: 0.5, entropy: 7.82, expectedConfidence: 0.99 };
    case 'File Transfer (SFTP/SCP)':
      return { minLen: 1300, maxLen: 1480, meanIatMs: 3, outboundProbability: 0.88, entropy: 7.99, expectedConfidence: 0.97 };
    default:
      return { minLen: 200, maxLen: 1000, meanIatMs: 50, outboundProbability: 0.5, entropy: 7.95, expectedConfidence: 0.90 };
  }
}

export function performSecurityAssessment(config: TestbedConfig): SecurityAssessmentReport {
  const findings: SecurityAssessmentReport['findings'] = [];
  const dh = DH_GROUPS[config.dhGroupId] || DH_GROUPS[14];
  let penalty = 0;

  // 1. IKE Version & Mode Checks
  if (config.ikeVersion === 'IKEv1') {
    penalty += 25;
    if (config.ikeMode === 'Aggressive Mode') {
      penalty += 20;
      findings.push({
        id: 'SEC-IKEV1-AGG-PSK',
        title: 'IKEv1 Aggressive Mode with Pre-Shared Key Vulnerability',
        severity: 'CRITICAL',
        category: 'Protocol Vulnerability',
        cveOrRfc: 'CVE-2002-1623 / RFC 2409 Section 5.4',
        description: 'IKEv1 Aggressive Mode sends the authentication hash (HASH_R/HASH_I) and identity unencrypted in the initial handshake frames. An eavesdropper can passively capture this exchange and execute high-speed offline dictionary/brute-force cracking (e.g., using Hashcat mode 5400 or ike-scan).',
        impact: 'Full compromise of VPN Pre-Shared Key, allowing unauthorized session decryption and active Man-in-the-Middle spoofing.',
        recommendation: 'Upgrade to IKEv2 immediately. If IKEv1 is strictly required by legacy hardware, switch to Main Mode with high-entropy RSA/ECDSA certificates instead of PSK.',
        remediationSnippet: `# StrongSwan / ipsec.conf remediation:
conn vpn-secure
    keyexchange=ikev2
    ike=aes256gcm16-prfsha384-ecp384!
    esp=aes256gcm16-ecp384!`
      });
    } else {
      findings.push({
        id: 'SEC-IKEV1-DEPRECATED',
        title: 'Deprecated IKEv1 Protocol in Use',
        severity: 'HIGH',
        category: 'Protocol Vulnerability',
        cveOrRfc: 'RFC 9395 / NIST SP 800-77 Rev 1',
        description: 'IKEv1 has been formally deprecated by the IETF (RFC 9395). It suffers from complex 6-packet negotiation overhead, lack of native asymmetric authentication, lack of built-in multi-homing (MOBIKE), and vulnerability to denial-of-service reflection.',
        impact: 'Increased attack surface, slower failover, and non-compliance with modern cybersecurity mandates.',
        recommendation: 'Migrate configuration to IKEv2 (Internet Key Exchange version 2).'
      });
    }
  }

  // 2. Cipher Suite Weakness Checks
  if (config.encryptionAlgo === '3DES-CBC' || config.encryptionAlgo === 'DES-CBC') {
    penalty += 35;
    findings.push({
      id: 'SEC-CIPHER-SWEET32',
      title: 'Vulnerable 64-bit Block Cipher (Sweet32 Attack)',
      severity: 'CRITICAL',
      category: 'Cryptographic Weakness',
      cveOrRfc: 'CVE-2016-2183 / Sweet32',
      description: 'Triple-DES (3DES) uses a 64-bit block size. Due to the birthday paradox, collision attacks become feasible after transferring ~32GB of data under the same key, enabling plaintext recovery of secret tokens.',
      impact: 'Plaintext recovery of sensitive data and cryptographic session hijacking.',
      recommendation: 'Disallow 3DES and DES. Upgrade to AES-256-GCM or ChaCha20-Poly1305 with AEAD.',
      remediationSnippet: `esp=aes256gcm16,aes128gcm16!`
    });
  } else if (config.encryptionAlgo === 'AES-128-CBC' || config.encryptionAlgo === 'AES-256-CBC') {
    if (config.authAlgo === 'HMAC-MD5' || config.authAlgo === 'HMAC-SHA1') {
      penalty += 15;
    }
    // CBC vs AEAD recommendation
    findings.push({
      id: 'SEC-CIPHER-NON-AEAD',
      title: 'Legacy CBC Mode Cipher (Non-AEAD Construction)',
      severity: 'LOW',
      category: 'Cryptographic Weakness',
      cveOrRfc: 'RFC 8221 Section 5',
      description: 'AES-CBC requires separate MAC verification (e.g. HMAC-SHA256). Misimplementations are vulnerable to padding oracle attacks. Modern IPsec standards mandate AEAD ciphers.',
      impact: 'Higher CPU overhead and potential padding oracle vulnerabilities if MAC validation is flawed.',
      recommendation: 'Switch to Authenticated Encryption with Associated Data (AEAD) such as AES-GCM or ChaCha20-Poly1305.'
    });
  }

  // 3. Hash / Integrity Weaknesses
  if (config.authAlgo === 'HMAC-MD5') {
    penalty += 30;
    findings.push({
      id: 'SEC-AUTH-MD5-BROKEN',
      title: 'Cryptographically Broken HMAC-MD5 Algorithm',
      severity: 'CRITICAL',
      category: 'Cryptographic Weakness',
      cveOrRfc: 'RFC 6151 / NIST SP 800-131A',
      description: 'MD5 is thoroughly broken with known collision and pre-image attacks. Using MD5 for IPsec integrity invalidates compliance under PCI-DSS, HIPAA, and FedRAMP.',
      impact: 'Potential forgery of packet authentication tags and authentication bypass.',
      recommendation: 'Replace HMAC-MD5 with HMAC-SHA256, HMAC-SHA512, or AES-GMAC.'
    });
  } else if (config.authAlgo === 'HMAC-SHA1') {
    penalty += 18;
    findings.push({
      id: 'SEC-AUTH-SHA1-WEAK',
      title: 'Weakened SHA-1 Integrity Hashing',
      severity: 'HIGH',
      category: 'Cryptographic Weakness',
      cveOrRfc: 'NIST SP 800-131A Transition Notice',
      description: 'SHA-1 has known theoretical collision attacks (SHAttered, Shambles). NIST has mandated complete phaseout of SHA-1 for federal and enterprise security.',
      impact: 'Fails federal compliance audits; diminished collision resistance.',
      recommendation: 'Upgrade to SHA-256 or SHA-384.'
    });
  }

  // 4. Diffie-Hellman Group Assessment
  if (dh.bitLength <= 1024) {
    penalty += 30;
    findings.push({
      id: 'SEC-DH-LOGJAM',
      title: 'Weak Diffie-Hellman Group Susceptible to Logjam (DH Group 1 / 2)',
      severity: 'CRITICAL',
      category: 'Cryptographic Weakness',
      cveOrRfc: 'CVE-2015-4000 / Logjam Attack',
      description: `Diffie-Hellman ${dh.name} provides only ~80 bits of symmetric security. Nation-state actors and well-resourced adversaries can precompute discrete logarithm tables for 1024-bit primes to passively decrypt IPsec sessions in real time.`,
      impact: 'Total compromise of session confidentiality and integrity across all past and future sessions.',
      recommendation: 'Enforce DH Group 14 (2048-bit MODP), Group 19 (256-bit ECP), or Group 21 (521-bit ECP) minimum.'
    });
  } else if (dh.bitLength === 1536) {
    penalty += 10;
    findings.push({
      id: 'SEC-DH-GROUP5-LEGACY',
      title: 'Legacy DH Group 5 (1536-bit)',
      severity: 'MEDIUM',
      category: 'Cryptographic Weakness',
      cveOrRfc: 'RFC 8221 / NIST SP 800-77',
      description: '1536-bit MODP DH Group 5 does not meet modern 128-bit security strength requirements (it provides ~90 bits equivalent security).',
      impact: 'Marginal security margin against modern computational clusters.',
      recommendation: 'Upgrade to DH Group 19 (ECP-256) or Group 14 (MODP-2048).'
    });
  }

  // 5. Perfect Forward Secrecy (PFS)
  if (!config.pfsEnabled) {
    penalty += 15;
    findings.push({
      id: 'SEC-PFS-DISABLED',
      title: 'Perfect Forward Secrecy (PFS) is Disabled for Child SAs',
      severity: 'HIGH',
      category: 'Configuration Flaw',
      cveOrRfc: 'RFC 7296 Section 1.3',
      description: 'Without PFS enabled, all Quick Mode / Child SAs derive their session encryption keys directly from the master IKE SA secret without performing an additional Diffie-Hellman exchange.',
      impact: 'If the long-term master key is ever leaked or compromised, all previously recorded encrypted traffic can be decrypted retroactively.',
      recommendation: 'Enable PFS for all Child SA rekeys by appending DH group to phase 2 proposals (e.g. esp=aes256gcm16-ecp256!).'
    });
  }

  // 6. Replay Protection & Key Lifetime
  if (!config.replayProtection) {
    penalty += 15;
    findings.push({
      id: 'SEC-REPLAY-DISABLED',
      title: 'IPsec Anti-Replay Protection Window Disabled',
      severity: 'HIGH',
      category: 'Configuration Flaw',
      cveOrRfc: 'RFC 4303 Section 3.4.3',
      description: 'Anti-replay window sequence verification is disabled. An active attacker on the path can capture valid encrypted ESP packets and reinject them into the network repeatedly.',
      impact: 'Replay attacks can duplicate financial transactions, disrupt routing state, or cause Denial of Service.',
      recommendation: 'Enable anti-replay protection with a minimum window size of 64 or 128 packets.'
    });
  }

  if (config.keyLifetimeHours > 24) {
    penalty += 8;
    findings.push({
      id: 'SEC-LIFETIME-EXCESSIVE',
      title: `Excessive Key Lifetime (${config.keyLifetimeHours} Hours)`,
      severity: 'MEDIUM',
      category: 'Configuration Flaw',
      cveOrRfc: 'NIST SP 800-77 Section 5.3',
      description: `Key lifetime of ${config.keyLifetimeHours} hours violates best practice limits (recommended max 8-12 hours or 100GB). Long lifetimes increase nonce/IV reuse probability and expand the window of exposure.`,
      impact: 'Heightened risk of IV collision and extended impact window in the event of key compromise.',
      recommendation: 'Set IKE SA lifetime to 8 hours and Child SA lifetime to 1-4 hours (or limit by byte count).'
    });
  }

  // Calculate final score
  const overallScore = Math.max(0, Math.min(100, 100 - penalty));
  let riskLevel: SecurityAssessmentReport['riskLevel'] = 'HARDENED / SECURE';
  if (overallScore < 45) riskLevel = 'CRITICAL RISK';
  else if (overallScore < 65) riskLevel = 'HIGH RISK';
  else if (overallScore < 80) riskLevel = 'MODERATE RISK';
  else if (overallScore < 95) riskLevel = 'LOW RISK';

  // Compliance checks
  const complianceChecks: ComplianceCheck[] = [
    {
      standard: 'NIST SP 800-77 Rev 1',
      status: overallScore >= 80 ? 'COMPLIANT' : overallScore >= 60 ? 'WARNING' : 'NON_COMPLIANT',
      passedRules: overallScore >= 80 ? 12 : overallScore >= 60 ? 8 : 4,
      totalRules: 12,
      details: [
        `IKE Protocol: ${config.ikeVersion === 'IKEv2' ? 'Pass (IKEv2 Mandated)' : 'Fail (IKEv1 Deprecated)'}`,
        `Cipher Suite: ${config.encryptionAlgo.includes('GCM') ? 'Pass (AEAD Required)' : 'Fail/Warn (CBC Legacy)'}`,
        `DH Strength: ${dh.bitLength >= 2048 || dh.type === 'ECP' ? 'Pass (>= 2048-bit)' : 'Fail (Sub-2048 bit)'}`,
        `PFS Status: ${config.pfsEnabled ? 'Pass (PFS Mandated)' : 'Fail (PFS Disabled)'}`
      ]
    },
    {
      standard: 'RFC 8221 (IPsec Crypto)',
      status: (config.encryptionAlgo.includes('GCM') || config.encryptionAlgo.includes('ChaCha')) && dh.bitLength >= 2048 ? 'COMPLIANT' : 'NON_COMPLIANT',
      passedRules: config.encryptionAlgo.includes('GCM') ? 6 : 2,
      totalRules: 6,
      details: [
        'MUST implement AES-GCM (RFC 4106)',
        'MUST NOT use DES, 3DES, or MD5',
        'SHOULD support Curve25519 or ECP-256'
      ]
    },
    {
      standard: 'BSI TR-02102-3',
      status: dh.bitLength >= 2048 && config.pfsEnabled ? 'COMPLIANT' : 'NON_COMPLIANT',
      passedRules: dh.bitLength >= 2048 ? 5 : 2,
      totalRules: 5,
      details: [
        'Mandates minimum 2000-bit equivalent key length',
        'Mandates Ephemeral Diffie-Hellman (PFS)'
      ]
    }
  ];

  // Threat Matrix
  const threatMatrix: SecurityAssessmentReport['threatMatrix'] = [
    {
      threat: 'Logjam Precomputation Attack (DH 1024)',
      likelihood: dh.bitLength <= 1024 ? 'HIGH' : 'LOW',
      impact: 'HIGH',
      status: dh.bitLength <= 1024 ? 'VULNERABLE' : 'PROTECTED',
      description: 'Precomputation of discrete logs against standardized weak primes allows passive session decryption.'
    },
    {
      threat: 'Sweet32 Birthday Collision Attack',
      likelihood: config.encryptionAlgo.includes('3DES') || config.encryptionAlgo.includes('DES') ? 'HIGH' : 'LOW',
      impact: 'HIGH',
      status: config.encryptionAlgo.includes('3DES') || config.encryptionAlgo.includes('DES') ? 'VULNERABLE' : 'PROTECTED',
      description: '64-bit block ciphers leak session tokens after 32GB of throughput due to ciphertext collisions.'
    },
    {
      threat: 'IKEv1 Aggressive PSK Offline Dictionary Attack',
      likelihood: config.ikeVersion === 'IKEv1' && config.ikeMode === 'Aggressive Mode' ? 'HIGH' : 'LOW',
      impact: 'HIGH',
      status: config.ikeVersion === 'IKEv1' && config.ikeMode === 'Aggressive Mode' ? 'VULNERABLE' : 'PROTECTED',
      description: 'Cleartext exchange of authentication hash enables GPU-accelerated hash cracking.'
    },
    {
      threat: 'ESP Anti-Replay Reinjection Attack',
      likelihood: !config.replayProtection ? 'HIGH' : 'LOW',
      impact: 'MEDIUM',
      status: !config.replayProtection ? 'VULNERABLE' : 'PROTECTED',
      description: 'Inability to detect duplicated sequence numbers allows adversary to re-execute captured transactions.'
    },
    {
      threat: 'Encrypted Traffic Fingerprinting (XGBoost Inferred)',
      likelihood: 'MEDIUM',
      impact: 'LOW',
      status: 'MITIGATED',
      description: `Statistical AI analysis can infer inner ${config.trafficType} payload patterns despite encryption.`
    }
  ];

  // Remediation Roadmap
  const remediationRoadmap: SecurityAssessmentReport['remediationRoadmap'] = [];
  let step = 1;
  if (config.ikeVersion === 'IKEv1') {
    remediationRoadmap.push({
      stepNumber: step++,
      title: 'Upgrade Protocol to IKEv2',
      action: 'Replace IKEv1 daemon configurations with IKEv2 to enable MOBIKE, fast rekeying, and eliminate unencrypted identity exposure.',
      priority: 'IMMEDIATE',
      configDiff: `- keyexchange=ikev1\n+ keyexchange=ikev2`
    });
  }
  if (config.encryptionAlgo.includes('3DES') || config.encryptionAlgo.includes('CBC')) {
    remediationRoadmap.push({
      stepNumber: step++,
      title: 'Enforce AEAD Ciphers (AES-256-GCM / ChaCha20)',
      action: 'Migrate ESP transform set to authenticated AEAD encryption (AES-256-GCM-16) to prevent padding oracle and Sweet32 risks.',
      priority: 'IMMEDIATE',
      configDiff: `- esp=3des-md5,aes128-sha1\n+ esp=aes256gcm16-ecp384,chacha20poly1305-curve25519!`
    });
  }
  if (dh.bitLength < 2048) {
    remediationRoadmap.push({
      stepNumber: step++,
      title: 'Upgrade Diffie-Hellman Group to Group 19 (ECP-256) or 14 (MODP-2048)',
      action: `Deprecate ${dh.name}. Configure modern elliptic curve or >= 2048-bit prime modulus.`,
      priority: 'HIGH',
      configDiff: `- ike=aes128-sha1-modp1024\n+ ike=aes256gcm16-prfsha384-ecp384!`
    });
  }
  if (!config.pfsEnabled) {
    remediationRoadmap.push({
      stepNumber: step++,
      title: 'Enable Perfect Forward Secrecy (PFS)',
      action: 'Require DH exchange during Phase 2 / Child SA rekeying.',
      priority: 'HIGH',
      configDiff: `- esp=aes256gcm16\n+ esp=aes256gcm16-ecp256!`
    });
  }

  return {
    overallScore,
    riskLevel,
    aiConfidenceScore: 97.8,
    assessmentTimestamp: new Date().toISOString(),
    summaryNarrative: `Automated assessment completed for ${config.name}. The deployment scored ${overallScore}/100, placing it in the "${riskLevel}" security category. ${findings.length} findings identified across cryptographic algorithms, protocol version, and key management parameters.`,
    identifiedProtocol: {
      protocolName: config.vpnMode === 'Tunnel' ? 'IPsec ESP Tunnel Mode (Protocol 50)' : 'IPsec ESP Transport Mode (Protocol 50)',
      ikeVersion: config.ikeVersion,
      inferredMode: config.vpnMode,
      encryption: config.encryptionAlgo,
      authentication: config.authAlgo,
      dhGroup: dh,
      pfs: config.pfsEnabled,
      ipVersion: config.ipVersion
    },
    findings,
    complianceChecks,
    threatMatrix,
    predictedTraffic: {
      trafficType: config.trafficType,
      confidence: 0.96,
      topFeatures: ['Mean Packet Length (bytes)', 'Inter-Arrival Time (IAT Jitter)', 'Packet Burst Ratio', 'Shannon Entropy']
    },
    remediationRoadmap
  };
}
