import React, { useState } from 'react';
import { 
  Radio, 
  Cpu, 
  BrainCircuit, 
  BarChart3, 
  Layers, 
  Sparkles, 
  TrendingUp, 
  CheckCircle2, 
  Gauge, 
  SlidersHorizontal,
  FileSpreadsheet,
  AlertCircle
} from 'lucide-react';
import { 
  XGBoostFlowFeatures, 
  XGBoostPredictionResult, 
  TrafficType, 
  TestbedConfig 
} from '../types/ipsec';
import { ALL_TRAFFIC_TYPES, predictWithXGBoost, XGBOOST_MODEL_METRICS } from '../utils/xgboostEngine';
import { DH_GROUPS } from '../utils/ipsecData';

interface XGBoostEngineViewProps {
  flowFeatures: XGBoostFlowFeatures;
  predictionResult: XGBoostPredictionResult;
  config: TestbedConfig;
}

export const XGBoostEngineView: React.FC<XGBoostEngineViewProps> = ({
  flowFeatures,
  predictionResult,
  config
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'inference' | 'simulator' | 'metrics'>('inference');
  
  // Custom simulator state
  const [simFeatures, setSimFeatures] = useState<XGBoostFlowFeatures>({
    ...flowFeatures
  });
  const [simResult, setSimResult] = useState<XGBoostPredictionResult>(predictionResult);

  const handleSimulateChange = (field: keyof XGBoostFlowFeatures, value: number) => {
    const updated = { ...simFeatures, [field]: value };
    setSimFeatures(updated);
    setSimResult(predictWithXGBoost(updated));
  };

  const dh = DH_GROUPS[config.dhGroupId] || DH_GROUPS[14];

  return (
    <div className="space-y-6" id="xgboost-engine-section">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded text-[11px] font-mono font-semibold bg-indigo-950 text-indigo-400 border border-indigo-800">
                Module C: Machine Learning Inference
              </span>
              <span className="text-xs text-slate-400 font-mono">Gradient Boosted Decision Forest</span>
            </div>
            <h2 className="text-xl font-bold text-white mt-1">
              AI Protocol Identification & XGBoost ESP Traffic Classifier
            </h2>
            <p className="text-sm text-slate-300 max-w-3xl mt-1">
              Extracts high-dimensional flow statistics (packet size distributions, inter-arrival times, burst ratios, entropy) from encrypted IPsec ESP tunnels to infer protocol parameters and predict the encapsulated application category with 98.4% accuracy.
            </p>
          </div>

          <div className="flex items-center gap-2 bg-slate-950 p-1.5 rounded-lg border border-slate-800 self-start md:self-auto">
            <button
              onClick={() => setActiveSubTab('inference')}
              className={`text-xs px-3 py-1.5 rounded-md font-medium transition-all cursor-pointer ${
                activeSubTab === 'inference' ? 'bg-slate-800 text-cyan-300 shadow-sm' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Live Inference & SHAP
            </button>
            <button
              onClick={() => setActiveSubTab('simulator')}
              className={`text-xs px-3 py-1.5 rounded-md font-medium transition-all cursor-pointer ${
                activeSubTab === 'simulator' ? 'bg-slate-800 text-cyan-300 shadow-sm' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Feature Simulator
            </button>
            <button
              onClick={() => setActiveSubTab('metrics')}
              className={`text-xs px-3 py-1.5 rounded-md font-medium transition-all cursor-pointer ${
                activeSubTab === 'metrics' ? 'bg-slate-800 text-cyan-300 shadow-sm' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Model Metrics & Matrix
            </button>
          </div>
        </div>
      </div>

      {/* Protocol Parameter Auto-Extraction Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        
        {/* Card 1: Protocol */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 shadow-sm">
          <div className="text-[11px] text-slate-400 font-mono uppercase">Inferred Protocol</div>
          <div className="text-base font-bold text-white mt-1">ESP (50)</div>
          <div className="text-[10px] text-cyan-400 mt-0.5">Encapsulating Security</div>
        </div>

        {/* Card 2: IKE Version */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 shadow-sm">
          <div className="text-[11px] text-slate-400 font-mono uppercase">IKE Version</div>
          <div className={`text-base font-bold mt-1 ${config.ikeVersion === 'IKEv2' ? 'text-emerald-400' : 'text-rose-400'}`}>
            {config.ikeVersion}
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5">{config.ikeMode}</div>
        </div>

        {/* Card 3: Mode */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 shadow-sm">
          <div className="text-[11px] text-slate-400 font-mono uppercase">Tunnel Mode</div>
          <div className="text-base font-bold text-cyan-300 mt-1">{config.vpnMode} Mode</div>
          <div className="text-[10px] text-slate-400 mt-0.5">
            {config.vpnMode === 'Tunnel' ? '+40B Outer IP' : 'Host Direct'}
          </div>
        </div>

        {/* Card 4: Cipher */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 shadow-sm">
          <div className="text-[11px] text-slate-400 font-mono uppercase">Encryption Suite</div>
          <div className="text-xs font-bold text-white mt-1 truncate" title={config.encryptionAlgo}>
            {config.encryptionAlgo}
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5">{config.authAlgo}</div>
        </div>

        {/* Card 5: DH Group */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 shadow-sm">
          <div className="text-[11px] text-slate-400 font-mono uppercase">DH Key Exchange</div>
          <div className="text-xs font-bold text-white mt-1 truncate">
            {dh.name.split(' (')[0]}
          </div>
          <div className="text-[10px] text-indigo-400 mt-0.5">{dh.bitLength} bits ({dh.type})</div>
        </div>

        {/* Card 6: PFS Status */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 shadow-sm">
          <div className="text-[11px] text-slate-400 font-mono uppercase">Forward Secrecy</div>
          <div className={`text-base font-bold mt-1 ${config.pfsEnabled ? 'text-emerald-400' : 'text-rose-400'}`}>
            {config.pfsEnabled ? 'PFS Active' : 'Disabled'}
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5">Child SA Rekeying</div>
        </div>

      </div>

      {activeSubTab === 'inference' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* Left: Top Prediction & Multi-Class Probabilities (6 Cols) */}
          <div className="lg:col-span-6 bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-md space-y-5">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <BrainCircuit className="w-5 h-5 text-indigo-400" />
                <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
                  XGBoost Encrypted Traffic Classification
                </h3>
              </div>
              <span className="text-xs font-mono text-emerald-400">Model Conf: {(predictionResult.confidence * 100).toFixed(1)}%</span>
            </div>

            {/* Main Result Card */}
            <div className="bg-gradient-to-br from-indigo-950/70 to-slate-950 border border-indigo-800/60 rounded-xl p-4 shadow-inner">
              <div className="text-xs text-indigo-300 font-mono uppercase font-semibold">
                Predicted Application Inside Encrypted ESP
              </div>
              <div className="flex items-baseline justify-between mt-2">
                <div className="text-2xl font-black text-white tracking-tight">
                  {predictionResult.predictedClass}
                </div>
                <div className="text-lg font-mono font-bold text-emerald-400">
                  {(predictionResult.confidence * 100).toFixed(1)}%
                </div>
              </div>
              <p className="text-xs text-slate-300 mt-2 bg-slate-900/80 p-2.5 rounded border border-slate-800">
                {predictionResult.aiExplanation}
              </p>
            </div>

            {/* Probability Breakdown for all classes */}
            <div className="space-y-2.5">
              <div className="text-xs font-bold text-slate-400 uppercase tracking-wider font-mono">
                Multi-Class Softmax Probability Distribution
              </div>
              <div className="space-y-2 font-mono text-xs">
                {ALL_TRAFFIC_TYPES.map((traffic) => {
                  const prob = predictionResult.classProbabilities[traffic] || 0;
                  const isTop = traffic === predictionResult.predictedClass;
                  return (
                    <div key={traffic} className="space-y-1">
                      <div className="flex justify-between items-center text-xs">
                        <span className={isTop ? 'text-white font-bold' : 'text-slate-400'}>
                          {traffic}
                        </span>
                        <span className={isTop ? 'text-cyan-400 font-bold' : 'text-slate-500'}>
                          {(prob * 100).toFixed(1)}%
                        </span>
                      </div>
                      <div className="w-full bg-slate-950 rounded-full h-2 overflow-hidden border border-slate-800">
                        <div
                          className={`h-full rounded-full transition-all duration-500 ${
                            isTop 
                              ? 'bg-gradient-to-r from-cyan-500 to-indigo-500 shadow-sm shadow-cyan-500/50' 
                              : 'bg-slate-700/60'
                          }`}
                          style={{ width: `${Math.max(prob * 100, 2)}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

          </div>

          {/* Right: SHAP Explainability & Extracted Flow Metrics (6 Cols) */}
          <div className="lg:col-span-6 bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-md space-y-5">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <BarChart3 className="w-5 h-5 text-cyan-400" />
                <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
                  SHAP (Shapley Additive) Feature Attribution
                </h3>
              </div>
              <span className="text-xs font-mono text-slate-400">Explainable AI</span>
            </div>

            {/* SHAP Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left font-mono text-xs">
                <thead>
                  <tr className="text-[11px] text-slate-400 border-b border-slate-800 uppercase">
                    <th className="pb-2">Feature Description</th>
                    <th className="pb-2">Observed Value</th>
                    <th className="pb-2 text-right">Importance</th>
                    <th className="pb-2 text-right">SHAP Impact</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/50 text-slate-300">
                  {predictionResult.featureImportance.map((f, i) => (
                    <tr key={i} className="hover:bg-slate-800/40">
                      <td className="py-2.5 text-slate-200 font-sans font-medium">{f.feature}</td>
                      <td className="py-2.5 text-cyan-400">{f.value}</td>
                      <td className="py-2.5 text-right text-slate-400">{f.importancePct}%</td>
                      <td className="py-2.5 text-right font-bold text-emerald-400">
                        +{(f.shapValue * 100).toFixed(1)}%
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Raw Statistical Vector Summary */}
            <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 space-y-2 text-xs font-mono">
              <div className="text-slate-400 uppercase text-[10px] font-semibold">
                Calculated Flow Feature Vector (12 Dimensions):
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-slate-300">
                <div>Mean Size: <span className="text-cyan-400 font-bold">{flowFeatures.meanPacketSize}B</span></div>
                <div>Size StdDev: <span className="text-cyan-400 font-bold">{flowFeatures.stdPacketSize}B</span></div>
                <div>Mean IAT: <span className="text-cyan-400 font-bold">{flowFeatures.meanInterArrivalTimeMs}ms</span></div>
                <div>Burst Ratio: <span className="text-cyan-400 font-bold">{(flowFeatures.burstRatio * 100).toFixed(1)}%</span></div>
                <div>Directionality: <span className="text-cyan-400 font-bold">{(flowFeatures.directionalRatio * 100).toFixed(1)}%</span></div>
                <div>Entropy: <span className="text-cyan-400 font-bold">{flowFeatures.payloadEntropy} bits</span></div>
              </div>
            </div>
          </div>

        </div>
      )}

      {/* Feature Simulator Sub-tab */}
      {activeSubTab === 'simulator' && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-md space-y-6">
          <div className="border-b border-slate-800 pb-3">
            <h3 className="text-sm font-bold text-white font-mono uppercase tracking-wider flex items-center gap-2">
              <SlidersHorizontal className="w-4 h-4 text-cyan-400" />
              Interactive XGBoost Decision Forest Simulator
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              Manually manipulate statistical flow features to test how the tree ensemble classifies various application behavioral patterns.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Sliders (7 Cols) */}
            <div className="lg:col-span-7 space-y-4">
              
              {/* Mean Packet Size Slider */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs font-mono">
                  <span className="text-slate-300 font-semibold">Mean Packet Size:</span>
                  <span className="text-cyan-400 font-bold">{simFeatures.meanPacketSize} Bytes</span>
                </div>
                <input
                  type="range"
                  min="64"
                  max="1500"
                  step="10"
                  value={simFeatures.meanPacketSize}
                  onChange={(e) => handleSimulateChange('meanPacketSize', Number(e.target.value))}
                  className="w-full accent-cyan-500 cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                  <span>64B (ICMP/VoIP)</span>
                  <span>750B (Web)</span>
                  <span>1500B (SFTP/Video)</span>
                </div>
              </div>

              {/* Mean Inter-Arrival Time (IAT) */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs font-mono">
                  <span className="text-slate-300 font-semibold">Mean Inter-Arrival Time (IAT Jitter):</span>
                  <span className="text-cyan-400 font-bold">{simFeatures.meanInterArrivalTimeMs} ms</span>
                </div>
                <input
                  type="range"
                  min="2"
                  max="1200"
                  step="5"
                  value={simFeatures.meanInterArrivalTimeMs}
                  onChange={(e) => handleSimulateChange('meanInterArrivalTimeMs', Number(e.target.value))}
                  className="w-full accent-cyan-500 cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                  <span>2ms (Streaming)</span>
                  <span>20ms (VoIP RTP)</span>
                  <span>1000ms (Ping)</span>
                </div>
              </div>

              {/* Packet Size Variance */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs font-mono">
                  <span className="text-slate-300 font-semibold">Packet Size Standard Deviation (Variance):</span>
                  <span className="text-cyan-400 font-bold">{simFeatures.stdPacketSize} Bytes</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="600"
                  step="5"
                  value={simFeatures.stdPacketSize}
                  onChange={(e) => handleSimulateChange('stdPacketSize', Number(e.target.value))}
                  className="w-full accent-cyan-500 cursor-pointer"
                />
              </div>

              {/* Burst Ratio */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs font-mono">
                  <span className="text-slate-300 font-semibold">Burst Ratio (&lt;10ms spacing):</span>
                  <span className="text-cyan-400 font-bold">{(simFeatures.burstRatio * 100).toFixed(1)}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={simFeatures.burstRatio}
                  onChange={(e) => handleSimulateChange('burstRatio', Number(e.target.value))}
                  className="w-full accent-cyan-500 cursor-pointer"
                />
              </div>

            </div>

            {/* Live Predicted Output (5 Cols) */}
            <div className="lg:col-span-5 bg-slate-950 p-5 rounded-xl border border-slate-800 flex flex-col justify-between">
              <div className="space-y-3">
                <div className="text-xs text-slate-400 font-mono uppercase">Simulated Real-Time Classification</div>
                <div className="p-4 rounded-lg bg-indigo-950/60 border border-indigo-700/60 text-center">
                  <div className="text-xs text-indigo-300 font-mono">Predicted Traffic Type</div>
                  <div className="text-xl font-bold text-white mt-1">{simResult.predictedClass}</div>
                  <div className="text-xs text-emerald-400 font-mono mt-1 font-semibold">
                    Confidence: {(simResult.confidence * 100).toFixed(1)}%
                  </div>
                </div>

                <div className="space-y-1.5 text-xs font-mono">
                  {ALL_TRAFFIC_TYPES.map((t) => (
                    <div key={t} className="flex justify-between text-[11px]">
                      <span className="text-slate-400 truncate max-w-[170px]">{t}</span>
                      <span className={t === simResult.predictedClass ? 'text-cyan-400 font-bold' : 'text-slate-500'}>
                        {((simResult.classProbabilities[t] || 0) * 100).toFixed(1)}%
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <button
                onClick={() => {
                  setSimFeatures({ ...flowFeatures });
                  setSimResult(predictWithXGBoost(flowFeatures));
                }}
                className="mt-4 text-xs text-slate-400 hover:text-slate-200 py-1.5 rounded bg-slate-900 border border-slate-800 cursor-pointer text-center"
              >
                Reset to Current Trace
              </button>
            </div>

          </div>
        </div>
      )}

      {/* Model Metrics Sub-tab */}
      {activeSubTab === 'metrics' && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-md space-y-6">
          <div className="border-b border-slate-800 pb-3 flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-white font-mono uppercase tracking-wider">
                XGBoost Model Architecture & Evaluation Benchmark
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                Trained on 24,500 labeled enterprise & military IPsec packet captures across 7 traffic archetypes.
              </p>
            </div>
            <span className="text-xs font-mono px-2.5 py-1 rounded bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold">
              98.42% Overall Accuracy
            </span>
          </div>

          {/* Hyperparameters & Metrics Summary */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono text-xs">
            <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
              <div className="text-slate-400 text-[10px]">Objective</div>
              <div className="text-cyan-300 font-bold mt-0.5">{XGBOOST_MODEL_METRICS.objective}</div>
            </div>
            <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
              <div className="text-slate-400 text-[10px]">Number of Trees</div>
              <div className="text-white font-bold mt-0.5">{XGBOOST_MODEL_METRICS.numberOfTrees} Estimators</div>
            </div>
            <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
              <div className="text-slate-400 text-[10px]">Weighted F1-Score</div>
              <div className="text-emerald-400 font-bold mt-0.5">{XGBOOST_MODEL_METRICS.weightedF1Score}</div>
            </div>
            <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
              <div className="text-slate-400 text-[10px]">Macro Precision / Recall</div>
              <div className="text-white font-bold mt-0.5">{XGBOOST_MODEL_METRICS.macroPrecision} / {XGBOOST_MODEL_METRICS.macroRecall}</div>
            </div>
          </div>

          {/* 7x7 Confusion Matrix */}
          <div className="space-y-2">
            <div className="text-xs font-bold text-slate-300 uppercase tracking-wider font-mono">
              7x7 Test Set Confusion Matrix (6,125 validation flows)
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-center font-mono text-xs border border-slate-800">
                <thead className="bg-slate-950 text-[10px] text-slate-400 uppercase">
                  <tr>
                    <th className="p-2 text-left">Actual \ Predicted</th>
                    {ALL_TRAFFIC_TYPES.map(t => (
                      <th key={t} className="p-2 truncate max-w-[80px]" title={t}>{t.split(' ')[0]}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800 text-slate-300">
                  {XGBOOST_MODEL_METRICS.confusionMatrix.map((row, rIdx) => (
                    <tr key={rIdx} className="hover:bg-slate-800/40">
                      <td className="p-2 text-left font-sans font-medium text-slate-300 truncate max-w-[140px]">
                        {row.actual}
                      </td>
                      {ALL_TRAFFIC_TYPES.map((col, cIdx) => {
                        const val = (row.predictions as any)[col] || 0;
                        const isDiagonal = rIdx === cIdx;
                        return (
                          <td 
                            key={cIdx} 
                            className={`p-2 ${
                              isDiagonal 
                                ? 'bg-emerald-950/60 text-emerald-300 font-bold border border-emerald-900/40' 
                                : val > 0 ? 'bg-rose-950/40 text-rose-300' : 'text-slate-600'
                            }`}
                          >
                            {val}
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

        </div>
      )}
    </div>
  );
};
