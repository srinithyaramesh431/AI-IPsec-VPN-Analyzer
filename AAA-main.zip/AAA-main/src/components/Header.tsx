import React from 'react';
import { 
  Shield, 
  ShieldAlert, 
  Cpu, 
  Activity, 
  FileText, 
  Bot, 
  Database, 
  Lock, 
  Radio, 
  Sparkles,
  Layers
} from 'lucide-react';
import { TestbedConfig } from '../types/ipsec';

export type TabType = 
  | 'testbed' 
  | 'traffic' 
  | 'ai-identification' 
  | 'security-assessment' 
  | 'audit-reports' 
  | 'ai-copilot' 
  | 'dataset-docs';

interface HeaderProps {
  activeTab: TabType;
  onSelectTab: (tab: TabType) => void;
  currentConfig: TestbedConfig;
  securityScore?: number;
  riskLevel?: string;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  onSelectTab,
  currentConfig,
  securityScore = 92,
  riskLevel = 'HARDENED / SECURE'
}) => {
  const getScoreColor = () => {
    if (securityScore >= 80) return 'text-emerald-400 border-emerald-500/30 bg-emerald-500/10';
    if (securityScore >= 60) return 'text-yellow-400 border-yellow-500/30 bg-yellow-500/10';
    return 'text-rose-400 border-rose-500/30 bg-rose-500/10';
  };

  const navItems: { id: TabType; label: string; icon: React.ElementType; badge?: string }[] = [
    { id: 'testbed', label: '1. VPN Testbed Lab', icon: Cpu, badge: 'Topology' },
    { id: 'traffic', label: '2. Wireshark Dissector', icon: Activity, badge: '3-Pane' },
    { id: 'ai-identification', label: '3. AI XGBoost Classifier', icon: Radio, badge: '98.4% Acc' },
    { id: 'security-assessment', label: '4. Security & Threats', icon: Shield, badge: riskLevel.split(' ')[0] },
    { id: 'audit-reports', label: '5. Audit Reports', icon: FileText, badge: 'CISO / Tech' },
    { id: 'ai-copilot', label: '6. AI Security Copilot', icon: Bot, badge: 'Gemini' },
    { id: 'dataset-docs', label: '7. Datasets & Docs', icon: Database, badge: 'Python ML' },
  ];

  return (
    <header className="bg-slate-900 border-b border-slate-800 sticky top-0 z-40 shadow-xl" id="main-header">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top Tier: Title, Badges, Metrics */}
        <div className="flex flex-col md:flex-row md:items-center justify-between py-3 gap-3">
          
          {/* Logo & Title */}
          <div className="flex items-center space-x-3">
            <div className="h-10 w-10 rounded-xl bg-gradient-to-tr from-cyan-600 to-indigo-600 flex items-center justify-center shadow-lg shadow-cyan-500/20 border border-cyan-400/30 shrink-0">
              <Lock className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center space-x-2 flex-wrap">
                <h1 className="text-lg font-bold tracking-tight text-white flex items-center gap-1.5 font-mono">
                  IPSEC<span className="text-cyan-400 font-sans font-extrabold">SHIELD</span> AI
                </h1>
                <span className="text-[10px] uppercase font-mono font-semibold px-2 py-0.5 rounded bg-cyan-950 text-cyan-400 border border-cyan-800">
                  XGBoost v2.4
                </span>
                <span className="text-[10px] uppercase font-mono font-semibold px-2 py-0.5 rounded bg-indigo-950 text-indigo-300 border border-indigo-800">
                  RFC 8221
                </span>
                <span className="text-[10px] uppercase font-mono font-semibold px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800">
                  NIST SP 800-77
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Automated IPsec Protocol Analyzer, Threat Assessment & XGBoost Encrypted Flow Classification
              </p>
            </div>
          </div>

          {/* Active Target Banner & Score */}
          <div className="flex items-center gap-3 self-start md:self-auto">
            <div className="bg-slate-950 p-2 rounded-lg border border-slate-800 flex items-center gap-2">
              <div className="text-right">
                <div className="text-[10px] font-mono text-slate-500 uppercase">Active Target</div>
                <div className="text-xs font-bold text-slate-200 truncate max-w-[170px] font-mono">
                  {currentConfig.name.split(':')[1] || currentConfig.name}
                </div>
              </div>
            </div>

            {/* Score Badge */}
            <div className={`flex items-center gap-2 px-3 py-2 rounded-lg border text-xs font-mono font-bold ${getScoreColor()}`}>
              <ShieldAlert className="w-4 h-4" />
              <div>
                <div className="text-[10px] opacity-75 uppercase">Security</div>
                <div>{securityScore}/100</div>
              </div>
            </div>
          </div>

        </div>

        {/* Navigation Tabs */}
        <nav className="flex space-x-1 overflow-x-auto no-scrollbar pt-1 pb-2" aria-label="Main Navigation">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                id={`tab-btn-${item.id}`}
                onClick={() => onSelectTab(item.id)}
                className={`flex items-center space-x-2 px-3 py-2 rounded-lg text-xs font-medium whitespace-nowrap transition-all cursor-pointer ${
                  isActive
                    ? 'bg-slate-800 text-cyan-300 shadow-sm border border-cyan-500/40 font-semibold'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40 border border-transparent'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-cyan-400' : 'text-slate-400'}`} />
                <span>{item.label}</span>
                {item.badge && (
                  <span className={`text-[10px] px-1.5 py-0.2 rounded font-mono ${
                    isActive ? 'bg-cyan-950 text-cyan-300 border border-cyan-800' : 'bg-slate-950 text-slate-500'
                  }`}>
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

      </div>
    </header>
  );
};
