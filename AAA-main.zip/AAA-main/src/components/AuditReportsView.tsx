import React, { useState } from 'react';
import { 
  FileText, 
  Download, 
  Copy, 
  Check, 
  Sparkles, 
  Printer, 
  ShieldAlert, 
  Cpu, 
  CheckCircle2, 
  AlertCircle, 
  Terminal, 
  RefreshCw 
} from 'lucide-react';
import { SecurityAssessmentReport, TestbedConfig, XGBoostFlowFeatures, XGBoostPredictionResult } from '../types/ipsec';

interface AuditReportsViewProps {
  report: SecurityAssessmentReport;
  config: TestbedConfig;
  flowFeatures: XGBoostFlowFeatures;
  predictionResult: XGBoostPredictionResult;
}

export const AuditReportsView: React.FC<AuditReportsViewProps> = ({
  report,
  config,
  flowFeatures,
  predictionResult
}) => {
  const [reportType, setReportType] = useState<'executive' | 'technical' | 'ai-deep'>('executive');
  const [aiReportText, setAiReportText] = useState<string | null>(null);
  const [isGeneratingAi, setIsGeneratingAi] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);

  const handleGenerateAiAudit = async () => {
    setIsGeneratingAi(true);
    try {
      const response = await fetch('/api/gemini/security-audit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          config,
          securityAssessment: report,
          flowFeatures,
          xgboostPrediction: predictionResult
        })
      });
      const data = await response.json();
      if (data.analysisMarkdown) {
        setAiReportText(data.analysisMarkdown);
      } else if (data.executiveSummary) {
        setAiReportText(`## Executive Summary\n\n${data.executiveSummary}\n\n## Threat Analysis\n\n${data.threatAnalysis}\n\n## RFC Compliance\n\n${data.rfcCompliance}\n\n## Remediation\n\n${data.remediationRoadmap?.join('\n')}`);
      }
    } catch (err) {
      console.error('Failed to generate AI report:', err);
      setAiReportText('Failed to generate real-time AI security audit. Please check server connectivity.');
    } finally {
      setIsGeneratingAi(false);
    }
  };

  const generateFullReportMarkdown = () => {
    return `# IPsec VPN Security Assessment & Protocol Audit Report
**Assessment Target:** ${config.name}
**Timestamp:** ${new Date(report.assessmentTimestamp).toUTCString()}
**Overall Security Score:** ${report.overallScore}/100 (${report.riskLevel})
**AI Classification Engine:** XGBoost Classifier v2.4 (Encrypted ESP Confidence: ${(predictionResult.confidence * 100).toFixed(1)}%)

---

## 1. Executive Summary
${report.summaryNarrative}

- **VPN Operational Mode:** ${report.identifiedProtocol.inferredMode} Mode (${report.identifiedProtocol.ipVersion})
- **Key Exchange Protocol:** ${report.identifiedProtocol.ikeVersion}
- **Encryption Algorithm:** ${report.identifiedProtocol.encryption}
- **Integrity/Auth Hash:** ${report.identifiedProtocol.authentication}
- **Diffie-Hellman Group:** ${report.identifiedProtocol.dhGroup.name} (${report.identifiedProtocol.dhGroup.bitLength}-bit ${report.identifiedProtocol.dhGroup.type})
- **Perfect Forward Secrecy (PFS):** ${report.identifiedProtocol.pfs ? 'ENABLED' : 'DISABLED (CRITICAL RISK)'}
- **Encapsulated Traffic Inferred:** ${predictionResult.predictedClass}

---

## 2. Identified Security Findings (${report.findings.length})
${report.findings.map((f, i) => `
### [${f.severity}] ${i + 1}. ${f.title}
- **Category:** ${f.category}
- **Reference:** ${f.cveOrRfc || 'N/A'}
- **Description:** ${f.description}
- **Impact:** ${f.impact}
- **Remediation:** ${f.recommendation}
${f.remediationSnippet ? `\`\`\`bash\n${f.remediationSnippet}\n\`\`\`` : ''}
`).join('\n')}

---

## 3. Threat Matrix & Adversary Vectors
${report.threatMatrix.map(t => `- **${t.threat}** [${t.status} - Likelihood: ${t.likelihood}, Impact: ${t.impact}]: ${t.description}`).join('\n')}

---

## 4. Compliance Verification
${report.complianceChecks.map(c => `- **${c.standard}:** ${c.status} (${c.passedRules}/${c.totalRules} Rules Passed)`).join('\n')}

---

## 5. Machine Learning Encrypted Flow Fingerprint
- **Mean Packet Size:** ${flowFeatures.meanPacketSize} Bytes
- **IAT Mean / Jitter:** ${flowFeatures.meanInterArrivalTimeMs} ms
- **Burst Ratio (<10ms):** ${(flowFeatures.burstRatio * 100).toFixed(1)}%
- **Entropy:** ${flowFeatures.payloadEntropy} bits/byte
- **Predicted Inner Application:** ${predictionResult.predictedClass} (${(predictionResult.confidence * 100).toFixed(1)}% confidence)
`;
  };

  const handleCopyReport = () => {
    const text = reportType === 'ai-deep' && aiReportText ? aiReportText : generateFullReportMarkdown();
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadReport = () => {
    const text = reportType === 'ai-deep' && aiReportText ? aiReportText : generateFullReportMarkdown();
    const dataStr = "data:text/markdown;charset=utf-8," + encodeURIComponent(text);
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `IPsec_Audit_Report_${config.id}_${Date.now()}.md`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div className="space-y-6" id="audit-reports-section">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded text-[11px] font-mono font-semibold bg-cyan-950 text-cyan-400 border border-cyan-800">
                Module E: Automated Audit Reporting
              </span>
              <span className="text-xs text-slate-400 font-mono">Executive & Technical Deliverables</span>
            </div>
            <h2 className="text-xl font-bold text-white mt-1">
              Automated Security Assessment & Compliance Reports
            </h2>
            <p className="text-sm text-slate-300 max-w-3xl mt-1">
              Export CISO-ready executive summaries, comprehensive RFC compliance audit logs, and actionable engineering remediation plans.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopyReport}
              className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold px-3 py-2 rounded-lg border border-slate-700 transition-all cursor-pointer"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              <span>{copied ? 'Copied' : 'Copy Report'}</span>
            </button>
            <button
              onClick={handleDownloadReport}
              className="flex items-center gap-1.5 bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold px-3.5 py-2 rounded-lg shadow transition-all cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Export Markdown</span>
            </button>
          </div>
        </div>

        {/* Report View Selector */}
        <div className="flex space-x-2 mt-5 border-t border-slate-800 pt-4">
          <button
            onClick={() => setReportType('executive')}
            className={`text-xs px-3.5 py-1.5 rounded-lg font-medium transition-all cursor-pointer ${
              reportType === 'executive' 
                ? 'bg-cyan-950 text-cyan-300 border border-cyan-800 font-bold' 
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Executive Summary (CISO)
          </button>
          <button
            onClick={() => setReportType('technical')}
            className={`text-xs px-3.5 py-1.5 rounded-lg font-medium transition-all cursor-pointer ${
              reportType === 'technical' 
                ? 'bg-cyan-950 text-cyan-300 border border-cyan-800 font-bold' 
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Technical Audit & Remediation
          </button>
          <button
            onClick={() => {
              setReportType('ai-deep');
              if (!aiReportText) handleGenerateAiAudit();
            }}
            className={`text-xs px-3.5 py-1.5 rounded-lg font-medium transition-all cursor-pointer flex items-center gap-1.5 ${
              reportType === 'ai-deep' 
                ? 'bg-indigo-950 text-indigo-300 border border-indigo-800 font-bold' 
                : 'text-indigo-400 hover:text-indigo-300'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>AI Deep Synthesis (Gemini 3.7)</span>
          </button>
        </div>
      </div>

      {/* Report Canvas Content */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-md space-y-6">
        
        {/* Executive View */}
        {reportType === 'executive' && (
          <div className="space-y-6 max-w-5xl mx-auto">
            <div className="border-b border-slate-800 pb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <h3 className="text-lg font-bold text-white">
                  Executive Cybersecurity Summary: {config.name}
                </h3>
                <p className="text-xs text-slate-400">
                  Target Scope: IPsec VPN Infrastructure Assessment • Generated on {new Date(report.assessmentTimestamp).toLocaleString()}
                </p>
              </div>
              <span className={`px-3 py-1 rounded-full text-xs font-mono font-bold border self-start sm:self-auto ${
                report.overallScore >= 80 ? 'bg-emerald-950 text-emerald-300 border-emerald-800' :
                report.overallScore >= 60 ? 'bg-yellow-950 text-yellow-300 border-yellow-800' :
                'bg-rose-950 text-rose-300 border-rose-800'
              }`}>
                {report.riskLevel} ({report.overallScore}/100)
              </span>
            </div>

            {/* Score Grid Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
                <div className="text-xs text-slate-400">Total Vulnerabilities</div>
                <div className="text-2xl font-bold text-white mt-1">{report.findings.length}</div>
                <div className="text-[11px] text-rose-400 mt-0.5">
                  {report.findings.filter(f => f.severity === 'CRITICAL').length} Critical
                </div>
              </div>

              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
                <div className="text-xs text-slate-400">Key Exchange (IKE)</div>
                <div className={`text-2xl font-bold mt-1 ${report.identifiedProtocol.ikeVersion === 'IKEv2' ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {report.identifiedProtocol.ikeVersion}
                </div>
                <div className="text-[11px] text-slate-400 mt-0.5">
                  {report.identifiedProtocol.ikeVersion === 'IKEv2' ? 'Compliant' : 'Deprecated'}
                </div>
              </div>

              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
                <div className="text-xs text-slate-400">Diffie-Hellman Group</div>
                <div className="text-xl font-bold text-cyan-300 mt-1 truncate">
                  {report.identifiedProtocol.dhGroup.name.split(' (')[0]}
                </div>
                <div className="text-[11px] text-slate-400 mt-0.5">
                  {report.identifiedProtocol.dhGroup.bitLength} bits
                </div>
              </div>

              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
                <div className="text-xs text-slate-400">AI Predicted Traffic</div>
                <div className="text-xl font-bold text-indigo-300 mt-1 truncate">
                  {predictionResult.predictedClass.split(' (')[0]}
                </div>
                <div className="text-[11px] text-emerald-400 mt-0.5">
                  {(predictionResult.confidence * 100).toFixed(1)}% ML Conf.
                </div>
              </div>
            </div>

            {/* Narrative Box */}
            <div className="bg-slate-950 p-5 rounded-xl border border-slate-800 space-y-3">
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider font-mono">
                Executive Security Narrative
              </h4>
              <p className="text-sm text-slate-300 leading-relaxed">
                {report.summaryNarrative}
              </p>
              <div className="text-xs text-slate-400 pt-2 border-t border-slate-800/80">
                <span className="text-cyan-400 font-semibold">CISO Recommendation: </span>
                {report.overallScore >= 80 
                  ? 'Maintain continuous monitoring. The current configuration exhibits strict conformance with modern defense and NIST SP 800-77 Rev 1 guidelines.'
                  : 'Immediate remediation is required. Cryptographic deprecations and potential PSK hash exposure significantly expand enterprise attack surface.'}
              </div>
            </div>
          </div>
        )}

        {/* Technical View */}
        {reportType === 'technical' && (
          <div className="space-y-6 max-w-5xl mx-auto">
            <div className="border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white font-mono uppercase tracking-wider">
                Technical Protocol Dissection & Remediation Roadmap
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                Detailed packet-level findings, RFC violation citations, and hardened configuration directives.
              </p>
            </div>

            {/* Remediation Step-by-Step */}
            <div className="space-y-4">
              <div className="text-xs font-bold text-cyan-400 uppercase tracking-wider font-mono">
                Priority Remediation Engineering Tasks
              </div>

              {report.remediationRoadmap.map((rem) => (
                <div key={rem.stepNumber} className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="w-6 h-6 rounded-full bg-cyan-950 text-cyan-400 border border-cyan-800 text-xs font-mono font-bold flex items-center justify-center">
                        {rem.stepNumber}
                      </span>
                      <span className="text-sm font-bold text-white">{rem.title}</span>
                    </div>
                    <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-rose-950 text-rose-300 border border-rose-800">
                      {rem.priority}
                    </span>
                  </div>

                  <p className="text-xs text-slate-300">{rem.action}</p>

                  {rem.configDiff && (
                    <pre className="p-2.5 bg-slate-900 text-emerald-300 font-mono text-[11px] rounded border border-slate-800 overflow-x-auto">
                      {rem.configDiff}
                    </pre>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* AI Deep Synthesis (Gemini 3.7) View */}
        {reportType === 'ai-deep' && (
          <div className="space-y-6 max-w-5xl mx-auto">
            <div className="border-b border-slate-800 pb-3 flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-white font-mono uppercase tracking-wider flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-indigo-400" />
                  Gemini 3.7 Flash AI Cryptographic Synthesis
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Autonomous threat modeling, mathematical discrete log analysis, and bespoke hardening narrative.
                </p>
              </div>

              <button
                onClick={handleGenerateAiAudit}
                disabled={isGeneratingAi}
                className="flex items-center gap-1.5 text-xs bg-indigo-600 hover:bg-indigo-500 text-white font-medium px-3 py-1.5 rounded-lg transition-all cursor-pointer disabled:opacity-50"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isGeneratingAi ? 'animate-spin' : ''}`} />
                <span>{isGeneratingAi ? 'Synthesizing...' : 'Regenerate'}</span>
              </button>
            </div>

            {isGeneratingAi ? (
              <div className="text-center py-16 space-y-3">
                <RefreshCw className="w-8 h-8 text-indigo-400 animate-spin mx-auto" />
                <div className="text-sm font-semibold text-white">
                  Gemini 3.7 Flash analyzing cryptographic session parameters...
                </div>
                <div className="text-xs text-slate-400">
                  Evaluating RFC 8221 compliance, Sweet32 birthday probabilities, and XGBoost flow features.
                </div>
              </div>
            ) : aiReportText ? (
              <div className="bg-slate-950 p-6 rounded-xl border border-slate-800 text-xs text-slate-200 leading-relaxed font-sans space-y-4 whitespace-pre-wrap">
                {aiReportText}
              </div>
            ) : (
              <div className="text-center py-12 text-slate-400 text-xs">
                Click "Regenerate" to run an automated AI Cryptographic Audit with Gemini.
              </div>
            )}
          </div>
        )}

      </div>
    </div>
  );
};
