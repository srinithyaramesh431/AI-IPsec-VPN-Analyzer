import React, { useState, useMemo } from 'react';
import { 
  Activity, 
  Search, 
  Filter, 
  ChevronRight, 
  ChevronDown, 
  FileCode, 
  Layers, 
  Upload, 
  Download, 
  Clock, 
  CheckCircle2, 
  AlertTriangle,
  Radio,
  Eye
} from 'lucide-react';
import { PacketDissection } from '../types/ipsec';

interface PacketDissectorProps {
  packets: PacketDissection[];
  selectedPacket: PacketDissection | null;
  onSelectPacket: (packet: PacketDissection) => void;
  onUploadTrace?: (file: File) => void;
}

export const PacketDissector: React.FC<PacketDissectorProps> = ({
  packets,
  selectedPacket,
  onSelectPacket
}) => {
  const [filterQuery, setFilterQuery] = useState('');
  const [expandedLayers, setExpandedLayers] = useState<Record<string, boolean>>({
    'layer-0': true,
    'layer-1': true,
    'layer-2': true
  });
  const [activeTab, setActiveTab] = useState<'dissector' | 'ladder' | 'pcap-export'>('dissector');

  // Filter logic
  const filteredPackets = useMemo(() => {
    if (!filterQuery.trim()) return packets;
    const q = filterQuery.toLowerCase();
    return packets.filter(p => 
      p.protocol.toLowerCase().includes(q) ||
      p.info.toLowerCase().includes(q) ||
      p.sourceIp.toLowerCase().includes(q) ||
      p.destIp.toLowerCase().includes(q) ||
      (p.spi && p.spi.toLowerCase().includes(q))
    );
  }, [packets, filterQuery]);

  const toggleLayer = (layerKey: string) => {
    setExpandedLayers(prev => ({
      ...prev,
      [layerKey]: !prev[layerKey]
    }));
  };

  const getProtocolBadge = (protocol: string) => {
    if (protocol.includes('IKEv2')) {
      return 'bg-emerald-950 text-emerald-300 border-emerald-800';
    }
    if (protocol.includes('IKEv1')) {
      return 'bg-rose-950 text-rose-300 border-rose-800';
    }
    if (protocol.includes('ESP')) {
      return 'bg-indigo-950 text-indigo-300 border-indigo-800';
    }
    return 'bg-slate-800 text-slate-300 border-slate-700';
  };

  const activePacket = selectedPacket || (packets.length > 0 ? packets[0] : null);

  const handleDownloadPcapJson = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(packets, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `ipsec_capture_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div className="space-y-5" id="packet-dissector-section">
      {/* Header Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-md flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-cyan-950 border border-cyan-800 text-cyan-400">
            <Activity className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              Protocol Packet Dissection Engine & Live Capture
              <span className="text-xs font-mono px-2 py-0.5 rounded bg-slate-800 text-cyan-300 border border-slate-700">
                {filteredPackets.length} Packets Captured
              </span>
            </h2>
            <p className="text-xs text-slate-400">
              Inspect Wireshark-compatible layers, IKE key exchange payloads, SPI records, and raw encrypted ESP payloads.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Tab Switcher */}
          <div className="bg-slate-950 p-1 rounded-lg border border-slate-800 flex">
            <button
              onClick={() => setActiveTab('dissector')}
              className={`text-xs px-3 py-1.5 rounded font-medium transition-all cursor-pointer ${
                activeTab === 'dissector' ? 'bg-slate-800 text-cyan-300' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Wireshark Dissector
            </button>
            <button
              onClick={() => setActiveTab('ladder')}
              className={`text-xs px-3 py-1.5 rounded font-medium transition-all cursor-pointer ${
                activeTab === 'ladder' ? 'bg-slate-800 text-cyan-300' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Handshake Ladder
            </button>
          </div>

          <button
            onClick={handleDownloadPcapJson}
            className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium px-3 py-2 rounded-lg border border-slate-700 transition-all cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Export Trace</span>
          </button>
        </div>
      </div>

      {activeTab === 'dissector' ? (
        <div className="space-y-4">
          {/* Filter Bar */}
          <div className="flex items-center gap-2 bg-slate-900 border border-slate-800 rounded-lg px-3 py-2">
            <Filter className="w-4 h-4 text-cyan-400" />
            <span className="text-xs font-mono text-slate-400">Display Filter:</span>
            <div className="relative flex-1">
              <input
                type="text"
                value={filterQuery}
                onChange={(e) => setFilterQuery(e.target.value)}
                placeholder='e.g., "esp", "ikev2", "198.51.100.10", "aggressive", "0x0d4f912c"'
                className="w-full bg-slate-950 border border-slate-800 text-xs text-slate-200 font-mono rounded px-2.5 py-1 focus:outline-none focus:border-cyan-500"
              />
              {filterQuery && (
                <button
                  onClick={() => setFilterQuery('')}
                  className="absolute right-2 top-1 text-slate-500 hover:text-slate-300 text-xs"
                >
                  ✕
                </button>
              )}
            </div>
            <div className="flex gap-1">
              {['esp', 'ike', '198.51'].map(preset => (
                <button
                  key={preset}
                  onClick={() => setFilterQuery(preset)}
                  className="text-[10px] font-mono bg-slate-800 hover:bg-slate-700 text-slate-300 px-2 py-1 rounded cursor-pointer"
                >
                  {preset}
                </button>
              ))}
            </div>
          </div>

          {/* 3-Pane Wireshark Dissector View */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
            
            {/* Top/Left Pane: Packet List Table (7 Cols) */}
            <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-md flex flex-col h-[520px]">
              <div className="bg-slate-950 px-4 py-2 border-b border-slate-800 text-xs font-semibold text-slate-300 flex items-center justify-between">
                <span>Packet Sequence Stream</span>
                <span className="text-[11px] font-mono text-cyan-400">Click packet to inspect payload</span>
              </div>
              
              <div className="overflow-y-auto flex-1 font-mono text-xs divide-y divide-slate-800/60">
                <table className="w-full text-left border-collapse">
                  <thead className="bg-slate-950/80 sticky top-0 z-10 text-[11px] text-slate-400 uppercase">
                    <tr>
                      <th className="py-2 px-2.5 font-medium w-12 text-center">No.</th>
                      <th className="py-2 px-2 font-medium w-20">Time</th>
                      <th className="py-2 px-2 font-medium w-28">Source</th>
                      <th className="py-2 px-2 font-medium w-28">Destination</th>
                      <th className="py-2 px-2 font-medium w-24">Protocol</th>
                      <th className="py-2 px-2 font-medium w-14 text-right">Len</th>
                      <th className="py-2 px-3 font-medium">Info</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/40">
                    {filteredPackets.map((pkt) => {
                      const isSelected = activePacket?.id === pkt.id;
                      return (
                        <tr
                          key={pkt.id}
                          id={`packet-row-${pkt.id}`}
                          onClick={() => onSelectPacket(pkt)}
                          className={`hover:bg-slate-800/60 cursor-pointer transition-colors ${
                            isSelected ? 'bg-cyan-950/80 text-cyan-200 border-l-4 border-l-cyan-400' : 'text-slate-300'
                          }`}
                        >
                          <td className="py-1.5 px-2.5 text-center text-slate-500 font-semibold">{pkt.id}</td>
                          <td className="py-1.5 px-2 text-slate-400">{pkt.relativeTime.toFixed(4)}s</td>
                          <td className="py-1.5 px-2 truncate max-w-[110px]" title={pkt.sourceIp}>{pkt.sourceIp}</td>
                          <td className="py-1.5 px-2 truncate max-w-[110px]" title={pkt.destIp}>{pkt.destIp}</td>
                          <td className="py-1.5 px-2">
                            <span className={`text-[10px] px-1.5 py-0.5 rounded border font-semibold ${getProtocolBadge(pkt.protocol)}`}>
                              {pkt.protocol.split(' ')[0]}
                            </span>
                          </td>
                          <td className="py-1.5 px-2 text-right text-slate-400">{pkt.length}</td>
                          <td className="py-1.5 px-3 truncate max-w-[180px] text-slate-300" title={pkt.info}>
                            {pkt.info}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Right Pane: Layer Details & Hex Dump (5 Cols) */}
            <div className="lg:col-span-5 flex flex-col gap-4">
              
              {/* Layer Tree */}
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-md h-[270px] overflow-y-auto">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-3">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-white font-mono">
                    <Layers className="w-4 h-4 text-cyan-400" />
                    <span>Layer Protocol Tree [Packet #{activePacket?.id || 1}]</span>
                  </div>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-950 text-slate-400 border border-slate-800">
                    {activePacket?.length || 0} bytes on wire
                  </span>
                </div>

                {activePacket ? (
                  <div className="space-y-2 text-xs font-mono">
                    {activePacket.dissectedLayers.map((layer, idx) => {
                      const layerKey = `layer-${idx}`;
                      const isExpanded = expandedLayers[layerKey] ?? true;
                      return (
                        <div key={idx} className="border border-slate-800/80 rounded bg-slate-950/60 overflow-hidden">
                          <button
                            type="button"
                            onClick={() => toggleLayer(layerKey)}
                            className="w-full text-left px-3 py-2 bg-slate-950 hover:bg-slate-900/90 text-cyan-300 font-semibold flex items-center justify-between cursor-pointer border-b border-slate-800/40"
                          >
                            <span className="flex items-center gap-1.5">
                              {isExpanded ? <ChevronDown className="w-3.5 h-3.5 text-cyan-400" /> : <ChevronRight className="w-3.5 h-3.5 text-slate-500" />}
                              <span>{layer.layerName}</span>
                            </span>
                            <span className="text-[10px] text-slate-500">{layer.fields.length} fields</span>
                          </button>

                          {isExpanded && (
                            <div className="p-2.5 space-y-1.5 text-[11px] bg-slate-950/40 divide-y divide-slate-900">
                              {layer.fields.map((f, fIdx) => (
                                <div key={fIdx} className="pt-1 first:pt-0 flex flex-col">
                                  <div className="flex items-baseline justify-between gap-2">
                                    <span className="text-slate-400">{f.name}:</span>
                                    <span className="text-slate-200 font-semibold text-right">{f.value}</span>
                                  </div>
                                  {f.description && (
                                    <div className="text-[10px] text-rose-400 mt-0.5">
                                      ⚠ {f.description}
                                    </div>
                                  )}
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="text-center py-12 text-slate-500 text-xs">
                    Select a packet from the list to inspect header details.
                  </div>
                )}
              </div>

              {/* Hex Dump Viewer */}
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-md flex-1 overflow-hidden flex flex-col">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-2">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-white font-mono">
                    <FileCode className="w-4 h-4 text-indigo-400" />
                    <span>Raw Packet Bytes (Hex Dump)</span>
                  </div>
                  <span className="text-[10px] font-mono text-indigo-400">Offset / Hex / ASCII</span>
                </div>

                <div className="bg-slate-950 p-2.5 rounded border border-slate-800 text-[11px] font-mono text-slate-300 overflow-x-auto max-h-44 flex-1">
                  {activePacket ? (
                    <div className="space-y-1">
                      <div className="text-slate-500 text-[10px]">
                        0000  {activePacket.rawHex}
                      </div>
                      {activePacket.payloadSummary && (
                        <div className="pt-2 text-[10px] text-cyan-400 border-t border-slate-800/60">
                          Decoded Summary: {activePacket.payloadSummary}
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="text-slate-500">No packet selected.</div>
                  )}
                </div>
              </div>

            </div>

          </div>
        </div>
      ) : (
        /* Handshake Sequence Ladder Diagram */
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-md space-y-6">
          <div className="border-b border-slate-800 pb-3">
            <h3 className="text-sm font-bold text-white font-mono uppercase tracking-wider">
              IKE Protocol Handshake Sequence Diagram (Message Ladder)
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              Visual timing and cryptographic payload exchanges between VPN Initiator and Responder.
            </p>
          </div>

          <div className="max-w-4xl mx-auto space-y-6 py-4">
            {/* Endpoints */}
            <div className="flex justify-between items-center text-center font-mono">
              <div className="bg-cyan-950 border border-cyan-700 px-4 py-2 rounded-lg text-cyan-300 font-bold text-xs">
                <div>VPN Initiator</div>
                <div className="text-[10px] text-slate-400 font-normal">198.51.100.10:500</div>
              </div>
              <div className="text-xs text-slate-500 font-sans font-semibold">
                Network Transit (Untrusted WAN)
              </div>
              <div className="bg-cyan-950 border border-cyan-700 px-4 py-2 rounded-lg text-cyan-300 font-bold text-xs">
                <div>VPN Responder</div>
                <div className="text-[10px] text-slate-400 font-normal">203.0.113.50:500</div>
              </div>
            </div>

            {/* Handshake Messages */}
            <div className="space-y-4 relative before:absolute before:left-1/2 before:top-0 before:bottom-0 before:w-0.5 before:bg-slate-800">
              {packets.filter(p => p.protocol.includes('IKE')).map((ikePkt, idx) => {
                const isToRight = ikePkt.flags?.includes('Initiator');
                return (
                  <div key={idx} className="relative z-10 flex items-center justify-between gap-4">
                    <div className={`w-1/2 ${isToRight ? 'text-left' : 'text-right'}`}>
                      {isToRight && (
                        <div className="bg-slate-950 p-3 rounded-lg border border-cyan-800/60 shadow text-xs space-y-1">
                          <div className="font-mono font-bold text-cyan-300 flex items-center gap-1.5">
                            <span className="text-[10px] px-1.5 py-0.2 rounded bg-cyan-900/60">#{ikePkt.id}</span>
                            {ikePkt.ikeExchangeType || ikePkt.info}
                          </div>
                          <div className="text-[11px] text-slate-400">{ikePkt.payloadSummary}</div>
                        </div>
                      )}
                    </div>

                    {/* Arrow Marker */}
                    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-slate-800 border border-slate-700 text-cyan-400 text-xs font-bold font-mono">
                      {isToRight ? '→' : '←'}
                    </div>

                    <div className={`w-1/2 ${!isToRight ? 'text-left' : 'text-right'}`}>
                      {!isToRight && (
                        <div className="bg-slate-950 p-3 rounded-lg border border-indigo-800/60 shadow text-xs space-y-1">
                          <div className="font-mono font-bold text-indigo-300 flex items-center gap-1.5">
                            <span className="text-[10px] px-1.5 py-0.2 rounded bg-indigo-900/60">#{ikePkt.id}</span>
                            {ikePkt.ikeExchangeType || ikePkt.info}
                          </div>
                          <div className="text-[11px] text-slate-400">{ikePkt.payloadSummary}</div>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Established Phase 2 / ESP Data Banner */}
            <div className="text-center p-3 rounded-lg bg-emerald-950/40 border border-emerald-800/60 text-emerald-300 text-xs font-mono">
              ✓ Child SA Established • Encrypted ESP Tunnel Active (Protocol 50)
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
