import React, { useState, useRef, useEffect } from 'react';
import { 
  Bot, 
  Send, 
  Sparkles, 
  User, 
  Terminal, 
  HelpCircle, 
  RefreshCw, 
  ShieldAlert, 
  Check 
} from 'lucide-react';
import { SecurityAssessmentReport, TestbedConfig, XGBoostFlowFeatures, XGBoostPredictionResult } from '../types/ipsec';

interface AiSecurityCopilotProps {
  config: TestbedConfig;
  report: SecurityAssessmentReport;
  flowFeatures: XGBoostFlowFeatures;
  predictionResult: XGBoostPredictionResult;
}

interface Message {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
}

export const AiSecurityCopilot: React.FC<AiSecurityCopilotProps> = ({
  config,
  report,
  flowFeatures,
  predictionResult
}) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'init-1',
      sender: 'assistant',
      text: `Hello! I am your AI IPsec Protocol & Cryptographic Security Copilot. 
I have analyzed **${config.name}** (Current Security Score: **${report.overallScore}/100** - **${report.riskLevel}**). 
The XGBoost AI classifier has inferred the encrypted ESP inner stream as **${predictionResult.predictedClass}** (${(predictionResult.confidence * 100).toFixed(1)}% confidence).

Feel free to ask me anything about protocol handshakes, cryptographic vulnerabilities (Logjam, Sweet32), strongSwan/Cisco configurations, or how machine learning fingerprints encrypted IPsec flows!`,
      timestamp: new Date().toLocaleTimeString()
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  const handleSendMessage = async (textToSend?: string) => {
    const text = textToSend || inputText;
    if (!text.trim() || isLoading) return;

    const userMsg: Message = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: text.trim(),
      timestamp: new Date().toLocaleTimeString()
    };

    setMessages(prev => [...prev, userMsg]);
    if (!textToSend) setInputText('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/gemini/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: text.trim(),
          context: {
            config,
            securityAssessment: report,
            flowFeatures,
            xgboostPrediction: predictionResult
          }
        })
      });

      const data = await response.json();
      const aiReply = data.reply || 'I processed your query regarding IPsec security architecture.';

      const assistantMsg: Message = {
        id: `ai-${Date.now()}`,
        sender: 'assistant',
        text: aiReply,
        timestamp: new Date().toLocaleTimeString()
      };

      setMessages(prev => [...prev, assistantMsg]);
    } catch (err) {
      console.error('Copilot chat error:', err);
      setMessages(prev => [
        ...prev,
        {
          id: `ai-err-${Date.now()}`,
          sender: 'assistant',
          text: 'Unable to reach the Gemini AI model service. Please ensure your API key or network connection is active.',
          timestamp: new Date().toLocaleTimeString()
        }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const samplePrompts = [
    'How can an adversary exploit IKEv1 Aggressive Mode with PSK offline?',
    'Explain the mathematical risk of Diffie-Hellman Group 2 (Logjam Attack).',
    'How does XGBoost infer inner VoIP RTP vs Video streaming inside encrypted ESP?',
    'Give me the exact strongSwan /etc/ipsec.conf to fix all current vulnerabilities.'
  ];

  return (
    <div className="space-y-6" id="ai-security-copilot-section">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded text-[11px] font-mono font-semibold bg-indigo-950 text-indigo-400 border border-indigo-800">
                Module F: Interactive AI Advisor
              </span>
              <span className="text-xs text-slate-400 font-mono">Gemini 3.7 Flash Reasoning</span>
            </div>
            <h2 className="text-xl font-bold text-white mt-1">
              AI IPsec Security Copilot & Cryptographic Advisor
            </h2>
            <p className="text-sm text-slate-300 max-w-3xl mt-1">
              Engage with an AI assistant grounded in RFC specifications, cryptographic attack trees, and practical IPsec VPN remediation strategies.
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs font-mono text-cyan-400 bg-slate-950 px-3 py-2 rounded-lg border border-slate-800">
            <Bot className="w-4 h-4 text-cyan-400" />
            <span>Active Context: {config.id}</span>
          </div>
        </div>
      </div>

      {/* Chat Container */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-md flex flex-col h-[600px]">
        
        {/* Messages Scroll Area */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 font-sans">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex gap-3 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {msg.sender === 'assistant' && (
                <div className="w-8 h-8 rounded-lg bg-indigo-950 border border-indigo-800 text-indigo-400 flex items-center justify-center shrink-0 shadow-sm mt-0.5">
                  <Bot className="w-4 h-4" />
                </div>
              )}

              <div
                className={`max-w-2xl rounded-xl p-4 text-xs leading-relaxed ${
                  msg.sender === 'user'
                    ? 'bg-cyan-600 text-white shadow-md'
                    : 'bg-slate-950 text-slate-200 border border-slate-800 shadow'
                }`}
              >
                <div className="flex items-center justify-between gap-4 mb-1 text-[10px] opacity-75 font-mono">
                  <span>{msg.sender === 'user' ? 'Security Analyst' : 'IPsec Shield AI'}</span>
                  <span>{msg.timestamp}</span>
                </div>
                <div className="whitespace-pre-wrap">{msg.text}</div>
              </div>

              {msg.sender === 'user' && (
                <div className="w-8 h-8 rounded-lg bg-cyan-950 border border-cyan-800 text-cyan-400 flex items-center justify-center shrink-0 shadow-sm mt-0.5">
                  <User className="w-4 h-4" />
                </div>
              )}
            </div>
          ))}

          {isLoading && (
            <div className="flex gap-3 justify-start">
              <div className="w-8 h-8 rounded-lg bg-indigo-950 border border-indigo-800 text-indigo-400 flex items-center justify-center shrink-0">
                <RefreshCw className="w-4 h-4 animate-spin" />
              </div>
              <div className="bg-slate-950 text-slate-400 border border-slate-800 rounded-xl p-4 text-xs flex items-center gap-2">
                <Sparkles className="w-3.5 h-3.5 text-indigo-400 animate-pulse" />
                <span>Analyzing cryptographic attack trees and generating response...</span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Suggested Quick Prompts */}
        <div className="bg-slate-950/90 border-t border-slate-800/80 px-4 py-2 flex items-center gap-2 overflow-x-auto no-scrollbar">
          <span className="text-[10px] font-mono text-slate-500 uppercase shrink-0">Suggested:</span>
          {samplePrompts.map((p, idx) => (
            <button
              key={idx}
              onClick={() => handleSendMessage(p)}
              disabled={isLoading}
              className="text-[11px] bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-cyan-300 px-2.5 py-1 rounded border border-slate-800 whitespace-nowrap transition-all cursor-pointer disabled:opacity-50"
            >
              {p}
            </button>
          ))}
        </div>

        {/* Input Bar */}
        <div className="p-3 bg-slate-950 border-t border-slate-800 flex gap-2">
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSendMessage();
              }
            }}
            placeholder="Ask about protocol handshakes, Logjam, Sweet32, or strongSwan configs..."
            className="flex-1 bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-cyan-500 font-sans"
          />
          <button
            onClick={() => handleSendMessage()}
            disabled={!inputText.trim() || isLoading}
            className="bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-white px-4 py-2 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer shadow"
          >
            <Send className="w-3.5 h-3.5" />
            <span>Send</span>
          </button>
        </div>

      </div>
    </div>
  );
};
