import React, { useState } from 'react';
import { 
  Shield, 
  ShieldAlert, 
  ShieldCheck, 
  AlertTriangle, 
  CheckCircle2, 
  XCircle, 
  AlertOctagon, 
  Lock, 
  Unlock, 
  Flame, 
  ChevronRight, 
  ChevronDown, 
  Key, 
  FileCheck, 
  Check, 
  Copy,
  ExternalLink
} from 'lucide-react';
import { SecurityAssessmentReport, SecurityFinding } from '../types/ipsec';

interface SecurityAssessmentViewProps {
  report: SecurityAssessmentReport;
}

export const SecurityAssessmentView: React.FC<SecurityAssessmentViewProps> = ({ report }) => {
  const [expandedFinding, setExpandedFinding] = useState<string | null>(
    report.findings.length > 0 ? report.findings[0].id : null
  );
  const [copiedSnippet, setCopiedSnippet] = useState<string | null>(null);

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSnippet(id);
    setTimeout(() => setCopiedSnippet(null), 2000);
  };

  const getScoreColor = (score: number) => {
    if (score >= 85) return 'text-emerald-400 border-emerald-500 bg-emerald-500/10';
    if (score >= 65) return 'text-yellow-400 border-yellow-500 bg-yellow-500/10';
    if (score >= 45) return 'text-amber-400 border-amber-500 bg-amber-500/10';
    return 'text-rose-400 border-rose-500 bg-rose-500/10';
  };

  const getSeverityBadge = (severity: SecurityFinding['severity']) => {
    switch (severity) {
      case 'CRITICAL':
        return 'bg-rose-950 text-rose-300 border-rose-700 font-bold';
      case 'HIGH':
        return 'bg-amber-950 text-amber-300 border-amber-700 font-bold';
      case 'MEDIUM':
        return 'bg-yellow-950 text-yellow-300 border-yellow-700';
      case 'LOW':
        return 'bg-blue-950 text-blue-300 border-blue-700';
      default:
        return 'bg-slate-800 text-slate-300 border-slate-700';
    }
  };

  return (
    <div className="space-y-6" id="security-assessment-section">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded text-[11px] font-mono font-semibold bg-rose-950 text-rose-400 border border-rose-800">
                Module D: Automated Cryptographic Audit
              </span>
              <span className="text-xs text-slate-400 font-mono">NIST SP 800-77 & RFC 8221 Engine</span>
            </div>
            <h2 className="text-xl font-bold text-white mt-1">
              IPsec Security Assessment & Threat Posture Matrix
            </h2>
            <p className="text-sm text-slate-300 max-w-3xl mt-1">
              Comprehensive evaluation of cryptographic primitives, protocol implementation weaknesses, key management lifetimes, replay protection, and standard compliance.
            </p>
          </div>

          <div className={`flex items-center gap-3 px-5 py-3 rounded-xl border text-center ${getScoreColor(report.overallScore)}`}>
            <div>
              <div className="text-xs uppercase font-mono tracking-wider font-semibold opacity-80">Security Score</div>
              <div className="text-3xl font-black font-mono">{report.overallScore}/100</div>
            </div>
            <div className="h-10 w-px bg-current opacity-30" />
            <div className="text-left">
              <div className="text-xs uppercase font-mono tracking-wider font-semibold opacity-80">Risk Rating</div>
              <div className="text-sm font-bold">{report.riskLevel}</div>
            </div>
          </div>
        </div>
      </div>

      {/* Grid: Cryptographic Parameter Evaluation & Compliance (12 Cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left: Cryptographic Primitives Checklist (6 Cols) */}
        <div className="lg:col-span-6 bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-md space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <Key className="w-5 h-5 text-cyan-400" />
              <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
                Cryptographic Primitives Audit
              </h3>
            </div>
            <span className="text-xs font-mono text-cyan-400">Cipher & Key State</span>
          </div>

          <div className="space-y-3 font-mono text-xs">
            {/* Cipher Check */}
            <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 flex items-start justify-between gap-3">
              <div className="space-y-1">
                <div className="text-slate-400 text-[11px] font-sans font-semibold">Encryption Cipher:</div>
                <div className="text-white font-bold text-sm">{report.identifiedProtocol.encryption}</div>
                <div className="text-[11px] text-slate-400 font-sans">
                  {report.identifiedProtocol.encryption.includes('GCM') 
                    ? '✓ Modern Authenticated AEAD mode (RFC 4106).' 
                    : report.identifiedProtocol.encryption.includes('3DES')
                    ? '✗ Vulnerable to 64-bit block Sweet32 collision attacks.'
                    : '⚠ Legacy CBC mode without AEAD integrity.'}
                </div>
              </div>
              <span className={`px-2 py-1 rounded text-[10px] font-bold border ${
                report.identifiedProtocol.encryption.includes('GCM') 
                  ? 'bg-emerald-950 text-emerald-300 border-emerald-800' 
                  : 'bg-rose-950 text-rose-300 border-rose-800'
              }`}>
                {report.identifiedProtocol.encryption.includes('GCM') ? 'HARDENED' : 'RISK'}
              </span>
            </div>

            {/* Auth / Hash Check */}
            <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 flex items-start justify-between gap-3">
              <div className="space-y-1">
                <div className="text-slate-400 text-[11px] font-sans font-semibold">Integrity / Authentication Hash:</div>
                <div className="text-white font-bold text-sm">{report.identifiedProtocol.authentication}</div>
                <div className="text-[11px] text-slate-400 font-sans">
                  {report.identifiedProtocol.authentication.includes('MD5')
                    ? '✗ MD5 has known cryptographic collision vulnerabilities.'
                    : report.identifiedProtocol.authentication.includes('SHA1')
                    ? '⚠ SHA-1 deprecated by NIST SP 800-131A.'
                    : '✓ Strong collision-resistant hash or AEAD tag.'}
                </div>
              </div>
              <span className={`px-2 py-1 rounded text-[10px] font-bold border ${
                report.identifiedProtocol.authentication.includes('MD5') || report.identifiedProtocol.authentication.includes('SHA1')
                  ? 'bg-rose-950 text-rose-300 border-rose-800'
                  : 'bg-emerald-950 text-emerald-300 border-emerald-800'
              }`}>
                {report.identifiedProtocol.authentication.includes('MD5') ? 'BROKEN' : report.identifiedProtocol.authentication.includes('SHA1') ? 'WEAK' : 'HARDENED'}
              </span>
            </div>

            {/* Diffie-Hellman Group */}
            <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 flex items-start justify-between gap-3">
              <div className="space-y-1">
                <div className="text-slate-400 text-[11px] font-sans font-semibold">Diffie-Hellman Group:</div>
                <div className="text-white font-bold text-sm">{report.identifiedProtocol.dhGroup.name}</div>
                <div className="text-[11px] text-slate-400 font-sans">
                  {report.identifiedProtocol.dhGroup.bitLength <= 1024
                    ? '✗ Vulnerable to Logjam discrete logarithm precomputation.'
                    : '✓ Meets 128+ bit symmetric security margin.'}
                </div>
              </div>
              <span className={`px-2 py-1 rounded text-[10px] font-bold border ${
                report.identifiedProtocol.dhGroup.bitLength <= 1024
                  ? 'bg-rose-950 text-rose-300 border-rose-800'
                  : 'bg-emerald-950 text-emerald-300 border-emerald-800'
              }`}>
                {report.identifiedProtocol.dhGroup.bitLength <= 1024 ? 'LOGJAM RISK' : 'SECURE'}
              </span>
            </div>

            {/* PFS & Anti-Replay */}
            <div className="grid grid-cols-2 gap-2">
              <div className="p-2.5 bg-slate-950 rounded border border-slate-800">
                <div className="text-slate-400 text-[10px] font-sans font-semibold">Forward Secrecy:</div>
                <div className={`font-bold mt-0.5 ${report.identifiedProtocol.pfs ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {report.identifiedProtocol.pfs ? '✓ PFS Active' : '✗ PFS Disabled'}
                </div>
              </div>
              <div className="p-2.5 bg-slate-950 rounded border border-slate-800">
                <div className="text-slate-400 text-[10px] font-sans font-semibold">IKE Protocol:</div>
                <div className={`font-bold mt-0.5 ${report.identifiedProtocol.ikeVersion === 'IKEv2' ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {report.identifiedProtocol.ikeVersion}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right: Compliance Checklists against Standards (6 Cols) */}
        <div className="lg:col-span-6 bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-md space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <FileCheck className="w-5 h-5 text-indigo-400" />
              <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
                Standard Compliance Verification
              </h3>
            </div>
            <span className="text-xs font-mono text-slate-400">NIST & RFC Mandates</span>
          </div>

          <div className="space-y-3">
            {report.complianceChecks.map((comp, idx) => (
              <div key={idx} className="p-3.5 bg-slate-950 rounded-lg border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="text-xs font-bold text-white font-mono">{comp.standard}</div>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold border ${
                    comp.status === 'COMPLIANT' 
                      ? 'bg-emerald-950 text-emerald-300 border-emerald-800' 
                      : comp.status === 'WARNING'
                      ? 'bg-yellow-950 text-yellow-300 border-yellow-800'
                      : 'bg-rose-950 text-rose-300 border-rose-800'
                  }`}>
                    {comp.status} ({comp.passedRules}/{comp.totalRules} Rules)
                  </span>
                </div>

                <div className="space-y-1 text-xs text-slate-300 font-mono">
                  {comp.details.map((d, dIdx) => (
                    <div key={dIdx} className="text-[11px] text-slate-400 flex items-center gap-1.5">
                      <span className="text-cyan-400">•</span>
                      <span>{d}</span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* Threat Matrix & Attack Surface Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-md space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <Flame className="w-5 h-5 text-rose-400" />
            <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
              Threat Matrix & Adversary Attack Surface Map
            </h3>
          </div>
          <span className="text-xs font-mono text-slate-400">Tactics & Techniques</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono text-xs border-collapse">
            <thead>
              <tr className="bg-slate-950 text-[10px] text-slate-400 uppercase border-b border-slate-800">
                <th className="py-2.5 px-3">Threat Vector / Attack Name</th>
                <th className="py-2.5 px-3">Likelihood</th>
                <th className="py-2.5 px-3">Impact</th>
                <th className="py-2.5 px-3">Status</th>
                <th className="py-2.5 px-3">Mechanism & Technical Exploitability</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 text-slate-300">
              {report.threatMatrix.map((threat, idx) => (
                <tr key={idx} className="hover:bg-slate-800/40">
                  <td className="py-3 px-3 font-sans font-bold text-white max-w-[200px]">
                    {threat.threat}
                  </td>
                  <td className="py-3 px-3">
                    <span className={`px-1.5 py-0.5 rounded text-[10px] ${
                      threat.likelihood === 'HIGH' ? 'text-rose-400 bg-rose-950/60' : 'text-slate-400 bg-slate-800'
                    }`}>
                      {threat.likelihood}
                    </span>
                  </td>
                  <td className="py-3 px-3">
                    <span className={`px-1.5 py-0.5 rounded text-[10px] ${
                      threat.impact === 'HIGH' ? 'text-amber-400 bg-amber-950/60' : 'text-slate-400 bg-slate-800'
                    }`}>
                      {threat.impact}
                    </span>
                  </td>
                  <td className="py-3 px-3">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                      threat.status === 'VULNERABLE'
                        ? 'bg-rose-950 text-rose-300 border-rose-700'
                        : 'bg-emerald-950 text-emerald-300 border-emerald-800'
                    }`}>
                      {threat.status}
                    </span>
                  </td>
                  <td className="py-3 px-3 font-sans text-xs text-slate-400 max-w-md">
                    {threat.description}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Identified Security Findings & Recommendations List */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-md space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-amber-400" />
            <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
              Identified Security Vulnerabilities & Remediation Steps ({report.findings.length})
            </h3>
          </div>
          <span className="text-xs font-mono text-amber-400">Actionable SecOps Fixes</span>
        </div>

        {report.findings.length === 0 ? (
          <div className="p-8 text-center bg-slate-950 rounded-lg border border-slate-800 text-emerald-400 text-sm font-mono">
            ✓ Zero critical vulnerabilities detected. This IPsec configuration conforms to hardened defense specifications.
          </div>
        ) : (
          <div className="space-y-3">
            {report.findings.map((finding) => {
              const isExpanded = expandedFinding === finding.id;
              return (
                <div
                  key={finding.id}
                  className="bg-slate-950 border border-slate-800 rounded-lg overflow-hidden transition-all shadow-sm"
                >
                  <button
                    type="button"
                    onClick={() => setExpandedFinding(isExpanded ? null : finding.id)}
                    className="w-full p-3.5 flex items-center justify-between gap-3 text-left hover:bg-slate-900/60 cursor-pointer"
                  >
                    <div className="flex items-center gap-3">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-mono border ${getSeverityBadge(finding.severity)}`}>
                        {finding.severity}
                      </span>
                      <div>
                        <div className="text-sm font-bold text-white">{finding.title}</div>
                        <div className="text-[11px] font-mono text-slate-400">{finding.category} • {finding.cveOrRfc}</div>
                      </div>
                    </div>
                    {isExpanded ? <ChevronDown className="w-4 h-4 text-slate-400" /> : <ChevronRight className="w-4 h-4 text-slate-400" />}
                  </button>

                  {isExpanded && (
                    <div className="px-4 pb-4 pt-2 border-t border-slate-800/80 space-y-3 bg-slate-900/40 text-xs">
                      <div>
                        <div className="font-semibold text-slate-300 mb-1">Description:</div>
                        <p className="text-slate-400 leading-relaxed">{finding.description}</p>
                      </div>

                      <div>
                        <div className="font-semibold text-rose-400 mb-1">Impact:</div>
                        <p className="text-slate-400 leading-relaxed">{finding.impact}</p>
                      </div>

                      <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-1">
                        <div className="font-semibold text-emerald-400">Actionable Remediation:</div>
                        <p className="text-slate-300 leading-relaxed">{finding.recommendation}</p>
                      </div>

                      {finding.remediationSnippet && (
                        <div className="relative">
                          <button
                            onClick={() => handleCopy(finding.remediationSnippet!, finding.id)}
                            className="absolute top-2 right-2 text-[10px] bg-slate-800 hover:bg-slate-700 text-slate-300 px-2 py-1 rounded border border-slate-700 flex items-center gap-1 cursor-pointer"
                          >
                            {copiedSnippet === finding.id ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                            <span>{copiedSnippet === finding.id ? 'Copied' : 'Copy Snippet'}</span>
                          </button>
                          <pre className="p-3 bg-slate-950 text-cyan-300 font-mono text-[11px] rounded border border-slate-800 overflow-x-auto">
                            {finding.remediationSnippet}
                          </pre>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
