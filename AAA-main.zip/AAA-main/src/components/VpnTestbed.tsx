import React, { useState } from 'react';
import { 
  Server, 
  Network, 
  Sliders, 
  ShieldCheck, 
  Layers, 
  KeyRound, 
  Globe, 
  Radio, 
  ArrowRight, 
  Copy, 
  Check, 
  Terminal,
  Zap,
  Lock,
  Unlock,
  Sparkles
} from 'lucide-react';
import { 
  TestbedConfig, 
  VPNMode, 
  IPVersion, 
  IKEVersion, 
  IKEMode, 
  EncryptionAlgo, 
  AuthAlgo, 
  TrafficType 
} from '../types/ipsec';
import { DH_GROUPS } from '../utils/ipsecData';

interface VpnTestbedProps {
  config: TestbedConfig;
  onUpdateConfig: (newConfig: TestbedConfig) => void;
  onRunSimulation: () => void;
  isSimulating: boolean;
}

export const VpnTestbed: React.FC<VpnTestbedProps> = ({
  config,
  onUpdateConfig,
  onRunSimulation,
  isSimulating
}) => {
  const [copiedType, setCopiedType] = useState<string | null>(null);
  const [configTab, setConfigTab] = useState<'strongswan' | 'cisco' | 'topology'>('topology');

  const handleCopy = (text: string, type: string) => {
    navigator.clipboard.writeText(text);
    setCopiedType(type);
    setTimeout(() => setCopiedType(null), 2000);
  };

  const isAead = config.encryptionAlgo.includes('GCM') || config.encryptionAlgo.includes('ChaCha');
  const dh = DH_GROUPS[config.dhGroupId] || DH_GROUPS[14];

  return (
    <div className="space-y-6" id="vpn-testbed-section">
      {/* Overview Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg relative overflow-hidden">
        <div className="absolute -right-16 -top-16 w-64 h-64 bg-cyan-500/5 rounded-full blur-3xl pointer-events-none" />
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded text-[11px] font-mono font-semibold bg-cyan-950 text-cyan-400 border border-cyan-800">
                Module A: Laboratory Environment
              </span>
              <span className="text-xs text-slate-400 font-mono">Topology & RFC Suite Generator</span>
            </div>
            <h2 className="text-xl font-bold text-white mt-1">
              IPsec VPN Testbed Generation & Configuration Lab
            </h2>
            <p className="text-sm text-slate-300 max-w-3xl mt-1">
              Establish virtual IPsec testbeds under arbitrary security postures. Emulate varied operational modes (Tunnel vs Transport), modern AEAD or legacy CBC ciphers, Diffie-Hellman groups, and inject real application traffic payloads.
            </p>
          </div>
          <button
            id="testbed-deploy-sim-btn"
            onClick={onRunSimulation}
            disabled={isSimulating}
            className="flex items-center justify-center gap-2 bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white font-semibold text-sm px-5 py-3 rounded-lg shadow-lg shadow-cyan-900/30 transition-all cursor-pointer whitespace-nowrap active:scale-95 disabled:opacity-50"
          >
            <Zap className="w-4 h-4 text-cyan-200 fill-cyan-200" />
            <span>{isSimulating ? 'Deploying & Capturing...' : 'Deploy & Run Capture'}</span>
          </button>
        </div>
      </div>

      {/* Grid: Configurator Form & Interactive Topology */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left: Testbed Parameters Configurator (7 Cols) */}
        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-md space-y-5">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <Sliders className="w-4 h-4 text-cyan-400" />
              <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
                Protocol & Cryptographic Parameters
              </h3>
            </div>
            <span className="text-xs text-cyan-400/80 font-mono">Dynamic RFC Verification</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            
            {/* VPN Mode */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center justify-between">
                <span>VPN Operational Mode</span>
                <span className="text-[10px] text-slate-400 font-mono">RFC 4301</span>
              </label>
              <div className="grid grid-cols-2 gap-2">
                {(['Tunnel', 'Transport'] as VPNMode[]).map((mode) => (
                  <button
                    key={mode}
                    type="button"
                    onClick={() => onUpdateConfig({ ...config, vpnMode: mode })}
                    className={`py-2 px-3 rounded-lg text-xs font-semibold border transition-all cursor-pointer text-center ${
                      config.vpnMode === mode
                        ? 'bg-cyan-950/80 border-cyan-500 text-cyan-300 shadow-sm shadow-cyan-500/20'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200'
                    }`}
                  >
                    {mode} Mode
                  </button>
                ))}
              </div>
              <p className="text-[11px] text-slate-400 mt-1">
                {config.vpnMode === 'Tunnel' 
                  ? '• Encapsulates entire IP packet with new outer IP header (Site-to-Site / Remote Access)' 
                  : '• Encapsulates only payload between end hosts (No extra IP header, intra-datacenter)'}
              </p>
            </div>

            {/* IKE Version & Mode */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center justify-between">
                <span>Key Exchange Protocol</span>
                <span className="text-[10px] text-slate-400 font-mono">IKEv1 / IKEv2</span>
              </label>
              <div className="grid grid-cols-2 gap-2">
                {(['IKEv2', 'IKEv1'] as IKEVersion[]).map((v) => (
                  <button
                    key={v}
                    type="button"
                    onClick={() => onUpdateConfig({ 
                      ...config, 
                      ikeVersion: v, 
                      ikeMode: v === 'IKEv2' ? 'IKE_SA_INIT' : 'Main Mode' 
                    })}
                    className={`py-2 px-3 rounded-lg text-xs font-semibold border transition-all cursor-pointer text-center ${
                      config.ikeVersion === v
                        ? v === 'IKEv2' 
                          ? 'bg-emerald-950/80 border-emerald-500 text-emerald-300'
                          : 'bg-rose-950/80 border-rose-500 text-rose-300'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    {v} {v === 'IKEv1' ? '(Legacy)' : '(Modern)'}
                  </button>
                ))}
              </div>
              {config.ikeVersion === 'IKEv1' && (
                <div className="mt-2 flex gap-2">
                  {(['Main Mode', 'Aggressive Mode'] as IKEMode[]).map((m) => (
                    <button
                      key={m}
                      type="button"
                      onClick={() => onUpdateConfig({ ...config, ikeMode: m })}
                      className={`text-[11px] py-1 px-2.5 rounded border transition-all cursor-pointer flex-1 ${
                        config.ikeMode === m
                          ? 'bg-rose-900/60 border-rose-400 text-rose-200 font-semibold'
                          : 'bg-slate-950 border-slate-800 text-slate-400'
                      }`}
                    >
                      {m}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Encryption Algorithm */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Encryption Cipher (ESP/IKE)
              </label>
              <select
                value={config.encryptionAlgo}
                onChange={(e) => onUpdateConfig({ ...config, encryptionAlgo: e.target.value as EncryptionAlgo })}
                className="w-full bg-slate-950 border border-slate-700/80 text-xs text-slate-200 font-mono rounded-lg p-2.5 focus:border-cyan-500 focus:outline-none cursor-pointer"
              >
                <optgroup label="Modern Authenticated (AEAD) - Recommended">
                  <option value="AES-256-GCM">AES-256-GCM (RFC 4106) [High Security]</option>
                  <option value="AES-128-GCM">AES-128-GCM (RFC 4106) [Fast Performance]</option>
                  <option value="ChaCha20-Poly1305">ChaCha20-Poly1305 (RFC 7634) [Mobile / Non-AES-NI]</option>
                </optgroup>
                <optgroup label="Legacy CBC Mode (Requires Separate MAC)">
                  <option value="AES-256-CBC">AES-256-CBC (RFC 3602)</option>
                  <option value="AES-128-CBC">AES-128-CBC (RFC 3602)</option>
                </optgroup>
                <optgroup label="Vulnerable / Deprecated Ciphers">
                  <option value="3DES-CBC">3DES-CBC (Vulnerable to Sweet32 / CVE-2016-2183)</option>
                </optgroup>
              </select>
            </div>

            {/* Authentication / Hash Algorithm */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Authentication & Integrity Hash
              </label>
              <select
                value={config.authAlgo}
                disabled={isAead}
                onChange={(e) => onUpdateConfig({ ...config, authAlgo: e.target.value as AuthAlgo })}
                className={`w-full bg-slate-950 border text-xs font-mono rounded-lg p-2.5 focus:border-cyan-500 focus:outline-none cursor-pointer ${
                  isAead ? 'border-slate-800 text-slate-500 opacity-60' : 'border-slate-700/80 text-slate-200'
                }`}
              >
                {isAead ? (
                  <option value="AES-GMAC">Integrated AEAD Tag (GMAC / Poly1305 128-bit)</option>
                ) : (
                  <>
                    <option value="HMAC-SHA512">HMAC-SHA-512 (Recommended)</option>
                    <option value="HMAC-SHA384">HMAC-SHA-384 (Recommended)</option>
                    <option value="HMAC-SHA256">HMAC-SHA-256 (NIST Standard)</option>
                    <option value="HMAC-SHA1">HMAC-SHA-1 (Legacy / Weakened)</option>
                    <option value="HMAC-MD5">HMAC-MD5 (Broken / Collisions)</option>
                  </>
                )}
              </select>
              {isAead && (
                <p className="text-[10px] text-cyan-400 mt-1">
                  ✓ AEAD cipher suite intrinsically provides integrated 128-bit MAC tag verification.
                </p>
              )}
            </div>

            {/* Diffie-Hellman Group */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center justify-between">
                <span>Diffie-Hellman Group</span>
                <span className={`text-[10px] font-mono px-1.5 py-0.2 rounded ${
                  dh.securityRating === 'INSECURE' ? 'bg-rose-950 text-rose-400 border border-rose-800' :
                  dh.securityRating === 'LEGACY' ? 'bg-yellow-950 text-yellow-400 border border-yellow-800' :
                  'bg-emerald-950 text-emerald-400 border border-emerald-800'
                }`}>
                  {dh.securityRating}
                </span>
              </label>
              <select
                value={config.dhGroupId}
                onChange={(e) => onUpdateConfig({ ...config, dhGroupId: Number(e.target.value) })}
                className="w-full bg-slate-950 border border-slate-700/80 text-xs text-slate-200 font-mono rounded-lg p-2.5 focus:border-cyan-500 focus:outline-none cursor-pointer"
              >
                <optgroup label="Modern Elliptic Curves (ECP & Edwards)">
                  <option value="19">Group 19 (256-bit ECP - NIST P-256) [Recommended]</option>
                  <option value="20">Group 20 (384-bit ECP - NIST P-384)</option>
                  <option value="21">Group 21 (521-bit ECP - NIST P-521) [Military-Grade]</option>
                  <option value="31">Group 31 (Curve25519 - RFC 8031)</option>
                </optgroup>
                <optgroup label="MODP Primes (Standard)">
                  <option value="14">Group 14 (2048-bit MODP) [Standard Baseline]</option>
                  <option value="5">Group 5 (1536-bit MODP) [Legacy Minimum]</option>
                </optgroup>
                <optgroup label="Vulnerable Small Primes (Logjam Attack)">
                  <option value="2">Group 2 (1024-bit MODP) [Vulnerable to Precomputation]</option>
                  <option value="1">Group 1 (768-bit MODP) [Trivially Breakable]</option>
                </optgroup>
              </select>
            </div>

            {/* Perfect Forward Secrecy & IP Version */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Key Management & IP Layer
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => onUpdateConfig({ ...config, pfsEnabled: !config.pfsEnabled })}
                  className={`py-2 px-2.5 rounded-lg text-xs font-semibold border transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                    config.pfsEnabled
                      ? 'bg-emerald-950/80 border-emerald-500 text-emerald-300'
                      : 'bg-rose-950/80 border-rose-500 text-rose-300'
                  }`}
                >
                  {config.pfsEnabled ? <Lock className="w-3.5 h-3.5" /> : <Unlock className="w-3.5 h-3.5" />}
                  <span>PFS {config.pfsEnabled ? 'Enabled' : 'Disabled'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => onUpdateConfig({ ...config, ipVersion: config.ipVersion === 'IPv4' ? 'IPv6' : 'IPv4' })}
                  className="py-2 px-2.5 rounded-lg text-xs font-semibold border bg-slate-950 border-slate-700/80 text-cyan-300 hover:border-cyan-500 transition-all cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <Globe className="w-3.5 h-3.5 text-cyan-400" />
                  <span>{config.ipVersion} Layer</span>
                </button>
              </div>
            </div>

            {/* Encapsulated Application Traffic Selection */}
            <div className="sm:col-span-2 bg-slate-950/60 p-3 rounded-lg border border-slate-800/80">
              <label className="block text-xs font-semibold text-slate-300 mb-2 flex items-center justify-between">
                <span className="flex items-center gap-1.5">
                  <Radio className="w-3.5 h-3.5 text-cyan-400" />
                  Encapsulated Traffic Stream (Inner Payload)
                </span>
                <span className="text-[10px] text-indigo-400 font-mono">Target for XGBoost AI Classifier</span>
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {(
                  [
                    'VoIP (RTP)',
                    'WhatsApp / Messaging',
                    'Video Streaming (HLS/DASH)',
                    'Web Browsing (HTTPS)',
                    'Email (SMTP/IMAP)',
                    'ICMP / Network Diagnostics',
                    'File Transfer (SFTP/SCP)'
                  ] as TrafficType[]
                ).map((traffic) => (
                  <button
                    key={traffic}
                    type="button"
                    onClick={() => onUpdateConfig({ ...config, trafficType: traffic })}
                    className={`py-1.5 px-2 rounded text-[11px] font-medium border transition-all cursor-pointer text-left truncate ${
                      config.trafficType === traffic
                        ? 'bg-indigo-950/90 border-indigo-500 text-indigo-200 font-bold shadow-sm'
                        : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700'
                    }`}
                  >
                    {traffic.split(' (')[0]}
                  </button>
                ))}
              </div>
            </div>

          </div>
        </div>

        {/* Right: Topology Visualizer & Config Exporters (5 Cols) */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-md flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800">
                <button
                  type="button"
                  onClick={() => setConfigTab('topology')}
                  className={`text-xs px-2.5 py-1 rounded font-medium transition-all cursor-pointer ${
                    configTab === 'topology' ? 'bg-slate-800 text-cyan-300 font-semibold' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Visual Topology
                </button>
                <button
                  type="button"
                  onClick={() => setConfigTab('strongswan')}
                  className={`text-xs px-2.5 py-1 rounded font-medium transition-all cursor-pointer ${
                    configTab === 'strongswan' ? 'bg-slate-800 text-cyan-300 font-semibold' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  strongSwan
                </button>
                <button
                  type="button"
                  onClick={() => setConfigTab('cisco')}
                  className={`text-xs px-2.5 py-1 rounded font-medium transition-all cursor-pointer ${
                    configTab === 'cisco' ? 'bg-slate-800 text-cyan-300 font-semibold' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Cisco IOS
                </button>
              </div>
              <span className="text-[11px] font-mono text-slate-400">Node Architecture</span>
            </div>

            {/* Topology Diagram View */}
            {configTab === 'topology' && (
              <div className="mt-4 space-y-3">
                <div className="p-3 bg-slate-950 rounded-lg border border-slate-800/80 space-y-3">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-400 font-mono">Traffic Flow:</span>
                    <span className="text-cyan-400 font-mono font-semibold">{config.trafficType}</span>
                  </div>

                  {/* Visual Node Chain */}
                  <div className="flex items-center justify-between text-center gap-1">
                    {/* Node 1 */}
                    <div className="flex-1 bg-slate-900 border border-slate-800 rounded p-2">
                      <Server className="w-4 h-4 mx-auto text-slate-300 mb-1" />
                      <div className="text-[10px] font-bold text-slate-200 truncate">Client Host</div>
                      <div className="text-[9px] font-mono text-slate-500">10.0.1.50</div>
                    </div>

                    <ArrowRight className="w-3.5 h-3.5 text-slate-600 shrink-0" />

                    {/* Gateway 1 */}
                    <div className="flex-1 bg-cyan-950/40 border border-cyan-700/50 rounded p-2 shadow-sm">
                      <ShieldCheck className="w-4 h-4 mx-auto text-cyan-400 mb-1" />
                      <div className="text-[10px] font-bold text-cyan-200 truncate">GW-Initiator</div>
                      <div className="text-[9px] font-mono text-cyan-400/80">198.51.100.10</div>
                    </div>

                    <ArrowRight className="w-3.5 h-3.5 text-cyan-500 animate-pulse shrink-0" />

                    {/* Encrypted Tunnel WAN */}
                    <div className="flex-1 bg-indigo-950/50 border border-indigo-700/60 rounded p-2 relative overflow-hidden">
                      <div className="absolute inset-0 bg-indigo-500/10 animate-pulse pointer-events-none" />
                      <Lock className="w-4 h-4 mx-auto text-indigo-300 mb-1" />
                      <div className="text-[10px] font-bold text-indigo-200 truncate">ESP Tunnel</div>
                      <div className="text-[9px] font-mono text-indigo-300/80">{config.encryptionAlgo.split('-')[0]}</div>
                    </div>

                    <ArrowRight className="w-3.5 h-3.5 text-indigo-500 animate-pulse shrink-0" />

                    {/* Gateway 2 */}
                    <div className="flex-1 bg-cyan-950/40 border border-cyan-700/50 rounded p-2 shadow-sm">
                      <ShieldCheck className="w-4 h-4 mx-auto text-cyan-400 mb-1" />
                      <div className="text-[10px] font-bold text-cyan-200 truncate">GW-Responder</div>
                      <div className="text-[9px] font-mono text-cyan-400/80">203.0.113.50</div>
                    </div>
                  </div>

                  {/* Packet Encapsulation Inspection preview */}
                  <div className="bg-slate-900/90 rounded p-2.5 border border-slate-800 font-mono text-[11px] space-y-1">
                    <div className="text-slate-400 text-[10px] uppercase font-sans font-semibold">Active Encapsulation Layer:</div>
                    <div className="flex flex-wrap gap-1 text-[10px]">
                      {config.vpnMode === 'Tunnel' && (
                        <span className="bg-blue-950 text-blue-300 px-1.5 py-0.5 rounded border border-blue-800">
                          Outer IP [40B]
                        </span>
                      )}
                      <span className="bg-indigo-950 text-indigo-300 px-1.5 py-0.5 rounded border border-indigo-800">
                        ESP Header (SPI: 0x0d4f912c, Seq: 1)
                      </span>
                      <span className="bg-purple-950 text-purple-300 px-1.5 py-0.5 rounded border border-purple-800">
                        Ciphertext [{config.encryptionAlgo}]
                      </span>
                      <span className="bg-emerald-950 text-emerald-300 px-1.5 py-0.5 rounded border border-emerald-800">
                        ICV / Tag [16B]
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* strongSwan Code Exporter */}
            {configTab === 'strongswan' && (
              <div className="mt-4 relative">
                <button
                  onClick={() => handleCopy(`# /etc/ipsec.conf
conn ipsec-tunnel-${config.id}
    type=${config.vpnMode.toLowerCase()}
    keyexchange=${config.ikeVersion.toLowerCase()}
    ike=${config.encryptionAlgo.toLowerCase().replace('-', '')}-prfsha384-ecp${dh.bitLength}!
    esp=${config.encryptionAlgo.toLowerCase().replace('-', '')}${config.pfsEnabled ? `-ecp${dh.bitLength}` : ''}!
    authby=secret
    auto=start`, 'strongswan')}
                  className="absolute top-2 right-2 text-xs bg-slate-800 hover:bg-slate-700 text-slate-300 px-2 py-1 rounded border border-slate-700 flex items-center gap-1 cursor-pointer"
                >
                  {copiedType === 'strongswan' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  <span>{copiedType === 'strongswan' ? 'Copied' : 'Copy'}</span>
                </button>
                <pre className="bg-slate-950 text-slate-300 font-mono text-[11px] p-3 rounded-lg border border-slate-800 overflow-x-auto max-h-56">
{`# /etc/ipsec.conf (strongSwan 5.x)
config setup
    charondebug="ike 2, knl 2, cfg 2"

conn ipsec-tunnel-${config.id}
    type=${config.vpnMode.toLowerCase()}
    keyexchange=${config.ikeVersion.toLowerCase()}
    ike=${config.encryptionAlgo.toLowerCase().replace('-', '')}-prfsha384-ecp${dh.bitLength}!
    esp=${config.encryptionAlgo.toLowerCase().replace('-', '')}${config.pfsEnabled ? `-ecp${dh.bitLength}` : ''}!
    ikelifetime=8h
    lifetime=2h
    authby=secret
    left=198.51.100.10
    leftsubnet=10.0.1.0/24
    right=203.0.113.50
    rightsubnet=10.0.2.0/24
    auto=start`}
                </pre>
              </div>
            )}

            {/* Cisco IOS Code Exporter */}
            {configTab === 'cisco' && (
              <div className="mt-4 relative">
                <button
                  onClick={() => handleCopy(`! Cisco IOS IPsec
crypto ikev2 proposal IKE2_PROP
 encryption ${config.encryptionAlgo.toLowerCase().includes('gcm') ? 'aes-gcm-256' : 'aes-cbc-256'}
 group ${config.dhGroupId}
!
crypto transform-set ESP_TS esp-${config.encryptionAlgo.toLowerCase().includes('gcm') ? 'gcm 256' : 'aes 256 esp-sha256-hmac'}
 mode ${config.vpnMode.toLowerCase()}`, 'cisco')}
                  className="absolute top-2 right-2 text-xs bg-slate-800 hover:bg-slate-700 text-slate-300 px-2 py-1 rounded border border-slate-700 flex items-center gap-1 cursor-pointer"
                >
                  {copiedType === 'cisco' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  <span>{copiedType === 'cisco' ? 'Copied' : 'Copy'}</span>
                </button>
                <pre className="bg-slate-950 text-slate-300 font-mono text-[11px] p-3 rounded-lg border border-slate-800 overflow-x-auto max-h-56">
{`! Cisco IOS XE / ASA Configuration
crypto ikev2 proposal IKE2_PROP_${config.id.toUpperCase().replace(/-/g, '_')}
 encryption ${config.encryptionAlgo.toLowerCase().includes('gcm') ? 'aes-gcm-256' : 'aes-cbc-256'}
 group ${config.dhGroupId}
!
crypto transform-set ESP_TRANSFORM esp-${config.encryptionAlgo.toLowerCase().includes('gcm') ? 'gcm 256' : 'aes 256 esp-sha256-hmac'}
 mode ${config.vpnMode.toLowerCase()}
!
crypto map IPSEC_MAP 10 ipsec-isakmp
 set peer 203.0.113.50
 set transform-set ESP_TRANSFORM
 ${config.pfsEnabled ? `set pfs group${config.dhGroupId}` : '! PFS Disabled'}
 match address VPN_ACL`}
                </pre>
              </div>
            )}

          </div>

          <div className="pt-3 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
            <span className="flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              Automated Packet Capture Ready
            </span>
            <span className="font-mono text-cyan-400 font-semibold">{config.packetCount} Packets in Buffer</span>
          </div>
        </div>

      </div>
    </div>
  );
};
